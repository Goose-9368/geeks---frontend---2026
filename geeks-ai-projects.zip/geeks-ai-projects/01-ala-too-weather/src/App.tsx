import { useQuery } from '@tanstack/react-query'
import { Link, useSearchParams } from 'react-router-dom'
import { ForecastView } from './ForecastView'
import { Button } from './shared/Button'
import { buildDemoForecast, cities, fetchForecast } from './weather'

export function App() {
  const [params, setParams] = useSearchParams()
  const city = cities.find((option) => option.id === params.get('city')) ?? cities[0]
  const demo = params.get('mode') === 'demo'
  const weather = useQuery({
    queryKey: ['weather', city.id],
    queryFn: ({ signal }) => fetchForecast(city, signal),
    enabled: !demo,
    networkMode: 'always',
    staleTime: 5 * 60 * 1000,
    retry: false,
    refetchOnWindowFocus: false,
  })
  const forecast = demo ? buildDemoForecast(city) : weather.data

  function selectCity(id: string) {
    const next = new URLSearchParams(params)
    next.set('city', id)
    setParams(next)
  }

  function toggleDemo() {
    const next = new URLSearchParams(params)
    if (demo) next.delete('mode')
    else next.set('mode', 'demo')
    setParams(next)
  }

  return (
    <div className="grid min-h-dvh grid-rows-[auto_1fr_auto]">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-8">
          <Link to="/" className="inline-flex items-center gap-3 rounded-lg text-lg font-extrabold tracking-tight">
            <span aria-hidden="true" className="grid size-9 place-items-center rounded-xl bg-accent text-lg text-white">☀</span>
            Ала-Тоо
          </Link>
          <Button variant="secondary" aria-pressed={demo} onClick={toggleDemo}>{demo ? 'Вернуться к прогнозу' : 'Режим примера'}</Button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl px-4 py-7 sm:px-8 sm:py-10">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Погода в Кыргызстане</h1>
          <div className="flex flex-wrap items-end gap-2.5">
            <div className="grid gap-1 text-sm font-semibold">
              <label htmlFor="weather-city">Город</label>
              <select
                id="weather-city"
                value={city.id}
                onChange={(event) => selectCity(event.currentTarget.value)}
                className="min-h-10 rounded-lg border border-line bg-surface px-3 pr-4 text-sm font-semibold"
              >
                {cities.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}
              </select>
            </div>
            {!demo && (
              <Button variant="secondary" disabled={weather.isFetching} onClick={() => void weather.refetch()}>
                {weather.isFetching ? 'Загрузка…' : 'Обновить'}
              </Button>
            )}
          </div>
        </div>

        {forecast ? (
          <>
            <ForecastView city={city} forecast={forecast} demo={demo} />
            {!demo && weather.isError && <p role="status" className="mt-4 text-sm text-muted">Обновление не удалось. Показан предыдущий прогноз.</p>}
          </>
        ) : weather.isError ? (
          <section role="alert" className="rounded-2xl border border-line bg-surface p-6">
            <h2 className="text-xl font-extrabold">Прогноз не загрузился</h2>
            <p className="mt-2 text-sm text-muted">{weather.error.message}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button onClick={() => void weather.refetch()}>Повторить</Button>
              <Button variant="secondary" onClick={toggleDemo}>Открыть пример</Button>
            </div>
          </section>
        ) : (
          <p role="status" className="min-h-44 rounded-2xl border border-line bg-surface p-6 text-sm font-semibold text-muted">
            Загружаем прогноз для города {city.name}…
          </p>
        )}
      </main>

      <footer className="border-t border-line bg-surface">
        <div className="mx-auto max-w-6xl px-4 py-4 text-sm text-muted sm:px-8">
          Источник прогноза <a className="font-bold text-accent underline underline-offset-2" href="https://open-meteo.com/">Open-Meteo</a>
        </div>
      </footer>
    </div>
  )
}
