import mountainPhoto from './assets/ala-too.jpg'
import { formatMeasurement, weatherCondition, type City, type Forecast, type ForecastDay } from './weather'

const shortDate = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', timeZone: 'UTC' })
const weekday = new Intl.DateTimeFormat('ru-RU', { weekday: 'short', timeZone: 'UTC' })

function DayCard({ day, index }: { day: ForecastDay; index: number }) {
  const date = new Date(day.date + 'T12:00:00Z')
  const condition = weatherCondition(day.code)

  return (
    <li className="flex h-full min-w-0 flex-col rounded-2xl border border-line bg-surface p-4 sm:p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-1">
        <span className="text-sm font-extrabold capitalize">{index === 0 ? 'Сегодня' : weekday.format(date)}</span>
        <time dateTime={day.date} className="text-xs font-semibold text-muted">{shortDate.format(date)}</time>
      </div>
      <span aria-hidden="true" className="mt-4 text-2xl">{condition.symbol}</span>
      <p className="mt-1.5 min-h-10 text-sm leading-snug text-muted">{condition.name}</p>
      <p className="mt-auto pt-3 text-lg font-extrabold tabular-nums">
        <span aria-label="Максимум">{formatMeasurement(day.maximum, '°')}</span>
        <span aria-label="Минимум" className="ml-2 text-sm font-semibold text-muted">{formatMeasurement(day.minimum, '°')}</span>
      </p>
      <p className="mt-2 text-xs text-muted">Осадки {formatMeasurement(day.rain, '%')}</p>
    </li>
  )
}

export function ForecastView({ city, forecast, demo }: { city: City; forecast: Forecast; demo: boolean }) {
  const now = weatherCondition(forecast.code)
  const measurements = [
    { label: 'Ощущается', text: formatMeasurement(forecast.feelsLike, ' °C') },
    { label: 'Влажность', text: formatMeasurement(forecast.humidity, '%') },
    { label: 'Ветер', text: formatMeasurement(forecast.wind, ' км/ч') },
  ]

  return (
    <>
      <section aria-labelledby="city-forecast" className="relative isolate overflow-hidden rounded-3xl bg-[#0b3449] text-white">
        <img src={mountainPhoto} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover object-[50%_58%]" />
        <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-r from-[#071f2e]/98 via-[#092a3c]/85 to-[#133d53]/45" />
        <div className="grid items-end gap-8 p-6 sm:p-9 lg:grid-cols-[1fr_minmax(20rem,0.9fr)] lg:p-10">
          <div>
            <p className="text-sm font-semibold text-sky-100">{demo ? 'Пример данных' : 'Текущая погода'}</p>
            <h2 id="city-forecast" className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">{city.name}</h2>
            <div className="mt-3 flex items-center gap-5">
              <span className="text-6xl leading-none font-black tracking-tight sm:text-7xl">{formatMeasurement(forecast.temperature, '°')}</span>
              <div>
                <span aria-hidden="true" className="text-3xl">{now.symbol}</span>
                <p className="mt-1 text-sm font-bold text-sky-50">{now.name}</p>
              </div>
            </div>
            {!demo && (
              <p className="mt-5 text-xs font-semibold text-sky-100">
                Данные на <time dateTime={forecast.time}>{forecast.time.slice(11, 16)}</time> по местному времени
              </p>
            )}
          </div>
          <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-white/25 bg-white/20 sm:grid-cols-3">
            {measurements.map(({ label, text }) => (
              <div key={label} className="bg-slate-900/55 p-3 sm:p-4">
                <dt className="text-xs font-semibold text-sky-100">{label}</dt>
                <dd className="mt-1 text-base font-extrabold tabular-nums">{text}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
      <section aria-labelledby="five-day-title" className="mt-8">
        <h2 id="five-day-title" className="mb-4 text-xl font-extrabold tracking-tight sm:text-2xl">Ближайшие пять дней</h2>
        <ul className="grid auto-rows-fr grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {forecast.days.map((day, index) => <DayCard key={day.date} day={day} index={index} />)}
        </ul>
      </section>
    </>
  )
}
