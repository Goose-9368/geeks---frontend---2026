import type { ComponentProps } from 'react'
import { cn } from './cn'

interface ButtonProps extends ComponentProps<'button'> {
  variant?: 'primary' | 'secondary' | 'quiet'
}

const variantClasses: Record<NonNullable<ButtonProps['variant']>, string> = {
  primary: 'border-accent bg-accent text-white enabled:hover:bg-hover',
  secondary: 'border-line bg-surface text-ink enabled:hover:border-accent enabled:hover:bg-soft',
  quiet: 'border-transparent text-accent enabled:hover:bg-soft',
}

export function Button({ variant = 'primary', type = 'button', className, ...props }: ButtonProps) {
  return (
    <button
      {...props}
      type={type}
      className={cn(
        'inline-flex min-h-10 items-center justify-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50',
        variantClasses[variant],
        className,
      )}
    />
  )
}
