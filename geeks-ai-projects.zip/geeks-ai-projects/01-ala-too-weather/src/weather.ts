export interface City {
  id: string
  name: string
  latitude: number
  longitude: number
}

export const cities: [City, ...City[]] = [
  { id: 'bishkek', name: 'Бишкек', latitude: 42.8746, longitude: 74.5698 },
  { id: 'karabalta', name: 'Кара-Балта', latitude: 42.8142, longitude: 73.8481 },
  { id: 'karakol', name: 'Каракол', latitude: 42.4907, longitude: 78.3936 },
  { id: 'osh', name: 'Ош', latitude: 40.5139, longitude: 72.8161 },
]

interface ApiForecast {
  current?: {
    time?: unknown
    temperature_2m?: unknown
    apparent_temperature?: unknown
    relative_humidity_2m?: unknown
    wind_speed_10m?: unknown
    weather_code?: unknown
  }
  daily?: {
    time?: unknown
    temperature_2m_max?: unknown[]
    temperature_2m_min?: unknown[]
    precipitation_probability_max?: unknown[]
    weather_code?: unknown[]
  }
}

export interface ForecastDay {
  date: string
  maximum: number | null
  minimum: number | null
  rain: number | null
  code: number | null
}

export interface Forecast {
  time: string
  temperature: number
  feelsLike: number | null
  humidity: number | null
  wind: number | null
  code: number | null
  days: ForecastDay[]
}

function numberOrNull(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

export async function fetchForecast(city: City, signal: AbortSignal): Promise<Forecast> {
  const params = new URLSearchParams({
    latitude: String(city.latitude),
    longitude: String(city.longitude),
    timezone: 'Asia/Bishkek',
    forecast_days: '5',
    temperature_unit: 'celsius',
    wind_speed_unit: 'kmh',
    current: 'temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code',
    daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
  })
  const response = await fetch('https://api.open-meteo.com/v1/forecast?' + params, { signal })
  if (!response.ok) throw new Error('Open-Meteo вернул ошибку ' + response.status + '.')

  const data = await response.json() as ApiForecast | null
  const current = data?.current
  const daily = data?.daily
  const temperature = numberOrNull(current?.temperature_2m)
  if (!current || !daily || typeof current.time !== 'string' || temperature === null ||
      !Array.isArray(daily.time) || daily.time.length < 5 || !daily.time.slice(0, 5).every(
        (date: unknown) => typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) &&
          Number.isFinite(Date.parse(date + 'T12:00:00Z')),
      )) {
    throw new Error('В ответе не хватает данных для прогноза.')
  }

  return {
    time: current.time,
    temperature,
    feelsLike: numberOrNull(current.apparent_temperature),
    humidity: numberOrNull(current.relative_humidity_2m),
    wind: numberOrNull(current.wind_speed_10m),
    code: numberOrNull(current.weather_code),
    days: daily.time.slice(0, 5).map((date: string, index) => ({
      date,
      maximum: numberOrNull(daily.temperature_2m_max?.[index]),
      minimum: numberOrNull(daily.temperature_2m_min?.[index]),
      rain: numberOrNull(daily.precipitation_probability_max?.[index]),
      code: numberOrNull(daily.weather_code?.[index]),
    })),
  }
}

const dayKey = new Intl.DateTimeFormat('sv-SE', {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  timeZone: 'Asia/Bishkek',
})

export function buildDemoForecast(city: City): Forecast {
  const now = new Date()
  const base = [8, 6, 3, 11][cities.indexOf(city)] ?? 8
  const dayExamples = [
    { maximum: 3, minimum: -4, rain: 10, code: 2 },
    { maximum: 5, minimum: -2, rain: 4, code: 0 },
    { maximum: 2, minimum: -3, rain: 40, code: 61 },
    { maximum: -1, minimum: -6, rain: 60, code: 71 },
    { maximum: 1, minimum: -5, rain: 18, code: 3 },
  ]

  return {
    time: dayKey.format(now) + 'T12:00',
    temperature: base,
    feelsLike: base - 2,
    humidity: 58,
    wind: 9,
    code: 2,
    days: dayExamples.map(({ maximum, minimum, rain, code }, index) => ({
      date: dayKey.format(new Date(now.getTime() + index * 86_400_000)),
      maximum: base + maximum,
      minimum: base + minimum,
      rain,
      code,
    })),
  }
}

export function weatherCondition(code: number | null) {
  if (code === 0) return { name: 'Ясно', symbol: '☀️' }
  if (code === 1 || code === 2) return { name: 'Переменная облачность', symbol: '⛅' }
  if (code === 3) return { name: 'Пасмурно', symbol: '☁️' }
  if (code === 45 || code === 48) return { name: 'Туман', symbol: '🌫️' }
  if (code !== null && ((code >= 71 && code <= 77) || code === 85 || code === 86)) return { name: 'Снег', symbol: '❄️' }
  if (code !== null && code >= 95) return { name: 'Гроза', symbol: '⛈️' }
  if (code !== null && code >= 51 && code <= 82) return { name: 'Дождь', symbol: '🌧️' }
  return { name: 'Нет данных', symbol: '—' }
}

export function formatMeasurement(value: number | null, unit: string): string {
  return value === null ? '—' : Math.round(value) + unit
}
