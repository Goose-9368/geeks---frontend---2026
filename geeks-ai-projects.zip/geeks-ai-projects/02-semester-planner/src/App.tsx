import { useEffect, useState } from 'react'
import { Link, NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { BoardPage } from './BoardPage'
import { CalendarPage } from './CalendarPage'
import { TaskDialog } from './TaskDialog'
import { dateFromToday } from './dates'
import { Button } from './shared/Button'
import { cn } from './shared/cn'
import type { Task } from './tasks'

const navigation = [
  { path: '/board', label: 'Доска' },
  { path: '/calendar', label: 'Календарь' },
]

export function App() {
  const [editor, setEditor] = useState<{ task?: Task; date: string } | null>(null)
  const { pathname } = useLocation()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  const editTask = (task: Task) => setEditor({ task, date: task.date })
  const createTask = (date: string) => setEditor({ date })

  return (
    <div className="grid min-h-dvh grid-rows-[auto_1fr]">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-6 gap-y-3 px-4 py-3.5 sm:px-8">
          <Link to="/board" className="inline-flex items-center gap-2.5 rounded-lg text-lg font-extrabold tracking-tight">
            <span aria-hidden="true" className="grid size-9 place-items-center rounded-xl bg-accent text-lg text-white">✓</span>
            Семестр
          </Link>
          <nav aria-label="Планер" className="order-last flex w-full flex-wrap gap-1 sm:order-none sm:w-auto">
            {navigation.map(({ path, label }) => (
              <NavLink
                key={path}
                to={path}
                className={({ isActive }) => cn('rounded-lg px-3 py-2 text-sm font-bold', isActive ? 'bg-soft text-accent' : 'text-muted hover:bg-canvas')}
              >
                {label}
              </NavLink>
            ))}
          </nav>
          <Button className="ml-auto" onClick={() => createTask(dateFromToday(0))}>Новая задача</Button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl px-4 py-7 sm:px-8 sm:py-9">
        <Routes>
          <Route path="/board" element={<BoardPage onEdit={editTask} />} />
          <Route path="/calendar" element={<CalendarPage onEdit={editTask} onCreate={createTask} />} />
          <Route path="*" element={<Navigate to="/board" replace />} />
        </Routes>
      </main>
      {editor && <TaskDialog task={editor.task} date={editor.date} onClose={() => setEditor(null)} />}
    </div>
  )
}
