import { useState } from 'react'
import { dateFromToday, formatDay } from './dates'
import { Button } from './shared/Button'
import { cn } from './shared/cn'
import { statuses, useTaskStore, type Task, type TaskStatus } from './tasks'

const statusColors: Record<TaskStatus, string> = {
  todo: 'bg-stone-300',
  doing: 'bg-amber-400',
  done: 'bg-green-500',
}

function TaskCard({ task, onEdit }: { task: Task; onEdit: (task: Task) => void }) {
  const setStatus = useTaskStore((state) => state.setStatus)
  const overdue = task.status !== 'done' && task.date < dateFromToday(0)

  return (
    <article className="min-w-0 rounded-xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-bold">
        <span className="max-w-full rounded-md bg-soft px-2 py-1 break-words text-accent">{task.subject}</span>
        {task.priority === 'high' && <span className="text-amber-800">Важно</span>}
      </div>
      <h3 className="mt-2 break-words text-base leading-snug font-extrabold">
        <button type="button" className="rounded-sm text-left hover:text-accent hover:underline" onClick={() => onEdit(task)}>{task.title}</button>
      </h3>
      {task.notes && <p className="mt-1.5 text-sm leading-relaxed break-words text-muted">{task.notes}</p>}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
        <p className={cn('text-xs font-semibold', overdue ? 'text-rose-700' : 'text-muted')}>
          {overdue && 'Просрочено · '}
          <time dateTime={task.date}>{formatDay(task.date)}</time>
        </p>
        <select
          aria-label={'Статус задачи «' + task.title + '»'}
          value={task.status}
          onChange={(event) => {
            const next = statuses.find((status) => status.id === event.currentTarget.value)
            if (next) setStatus(task.id, next.id)
          }}
          className="min-h-8 max-w-full rounded-md border border-line bg-surface px-1.5 text-xs font-semibold"
        >
          {statuses.map((status) => <option key={status.id} value={status.id}>{status.name}</option>)}
        </select>
      </div>
    </article>
  )
}

export function BoardPage({ onEdit }: { onEdit: (task: Task) => void }) {
  const tasks = useTaskStore((state) => state.tasks)
  const [search, setSearch] = useState('')
  const [subject, setSubject] = useState('')
  const subjects = [...new Set(tasks.map((task) => task.subject))].sort((a, b) => a.localeCompare(b, 'ru'))
  const selectedSubject = subjects.includes(subject) ? subject : ''
  const query = search.trim().toLocaleLowerCase('ru')
  const visible = tasks.filter((task) => (
    (!selectedSubject || task.subject === selectedSubject) &&
    (task.title + ' ' + task.subject).toLocaleLowerCase('ru').includes(query)
  ))
  const counters = [
    { label: 'Всего задач', value: tasks.length },
    { label: 'В работе', value: tasks.filter((task) => task.status === 'doing').length },
    { label: 'Готово', value: tasks.filter((task) => task.status === 'done').length },
  ]

  return (
    <>
      <div className="mb-6">
        <p className="mb-2 text-sm font-semibold text-accent">Сегодня, {formatDay(dateFromToday(0))}</p>
        <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Учебные задачи</h1>
      </div>
      <dl className="mb-6 grid grid-cols-3 gap-2.5 sm:gap-4">
        {counters.map(({ label, value }) => (
          <div key={label} className="min-w-0 rounded-xl border border-line bg-surface p-3 sm:p-5">
            <dt className="text-xs font-semibold text-muted sm:text-sm">{label}</dt>
            <dd className="mt-2 text-2xl font-black tabular-nums sm:text-3xl">{value}</dd>
          </div>
        ))}
      </dl>
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <label className="grid min-w-40 flex-1 gap-1 text-sm font-semibold sm:max-w-sm">
          Поиск
          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.currentTarget.value)}
            placeholder="Название задачи или предмет"
            className="min-h-10 rounded-lg border border-line bg-surface px-3 text-sm"
          />
        </label>
        <div className="grid min-w-0 max-w-full gap-1 text-sm font-semibold">
          <label htmlFor="board-subject">Предмет</label>
          <select id="board-subject" value={selectedSubject} onChange={(event) => setSubject(event.currentTarget.value)} className="min-h-10 max-w-full rounded-lg border border-line bg-surface px-3 text-sm">
            <option value="">Все предметы</option>
            {subjects.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </div>
        {(search || selectedSubject) && <Button variant="quiet" onClick={() => { setSearch(''); setSubject('') }}>Сбросить</Button>}
      </div>
      <div className="grid items-start gap-4 lg:grid-cols-3">
        {statuses.map((status) => {
          const items = visible.filter((task) => task.status === status.id)
          return (
            <section key={status.id} aria-label={status.name} className="min-w-0 rounded-2xl border border-line bg-soft/50 p-3 sm:p-4">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
                <span aria-hidden="true" className={cn('size-2 rounded-full', statusColors[status.id])} />
                {status.name}
                <span className="ml-auto rounded-md bg-surface px-2 py-0.5 text-xs text-muted">{items.length}</span>
              </h2>
              {items.length ? (
                <div className="grid gap-2.5">
                  {items.map((task) => <TaskCard key={task.id} task={task} onEdit={onEdit} />)}
                </div>
              ) : <p className="rounded-xl border border-dashed border-line bg-surface p-4 text-sm text-muted">В этой колонке пока пусто.</p>}
            </section>
          )
        })}
      </div>
    </>
  )
}
