import { useState } from 'react'
import { dateFromToday, dateKey, formatDay, getMonthCells } from './dates'
import { Button } from './shared/Button'
import { cn } from './shared/cn'
import { statuses, useTaskStore, type Task } from './tasks'

const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
const monthFormatter = new Intl.DateTimeFormat('ru-RU', { month: 'long' })

interface CalendarPageProps {
  onEdit: (task: Task) => void
  onCreate: (date: string) => void
}

export function CalendarPage({ onEdit, onCreate }: CalendarPageProps) {
  const tasks = useTaskStore((state) => state.tasks)
  const [month, setMonth] = useState(() => new Date())
  const [selected, setSelected] = useState(() => dateFromToday(0))
  const today = dateFromToday(0)
  const cells = getMonthCells(month)
  const dailyTasks = tasks.filter((task) => task.date === selected)

  function moveMonth(direction: number) {
    const next = new Date(month.getFullYear(), month.getMonth() + direction, 1)
    setMonth(next)
    setSelected(dateKey(next))
  }

  function jumpToToday() {
    setMonth(new Date())
    setSelected(today)
  }

  return (
    <>
      <h1 className="mb-6 text-3xl font-black tracking-tight sm:text-4xl">Календарь задач</h1>
      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.45fr)_minmax(0,0.85fr)]">
        <section aria-labelledby="month-label" className="min-w-0 overflow-hidden rounded-2xl border border-line bg-surface">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 sm:p-4">
            <h2 id="month-label" className="text-lg font-extrabold capitalize">{monthFormatter.format(month)} {month.getFullYear()}</h2>
            <div className="flex gap-1.5">
              <Button variant="secondary" aria-label="Предыдущий месяц" onClick={() => moveMonth(-1)} className="min-h-9 px-2.5 py-1">‹</Button>
              <Button variant="secondary" onClick={jumpToToday} className="min-h-9 px-2.5 py-1">Сегодня</Button>
              <Button variant="secondary" aria-label="Следующий месяц" onClick={() => moveMonth(1)} className="min-h-9 px-2.5 py-1">›</Button>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-px border-t border-line bg-line">
            {weekdays.map((day) => <div key={day} className="bg-canvas py-2 text-center text-xs font-bold text-muted">{day}</div>)}
            {cells.map((day, index) => {
              if (day === null) return <div key={index} className="bg-canvas" aria-hidden="true" />
              const value = dateKey(new Date(month.getFullYear(), month.getMonth(), day))
              const count = tasks.filter((task) => task.date === value).length
              return (
                <button
                  key={index}
                  type="button"
                  aria-label={formatDay(value) + ', задач ' + count}
                  aria-current={value === today ? 'date' : undefined}
                  aria-pressed={value === selected}
                  onClick={() => setSelected(value)}
                  className={cn(
                    'relative flex min-h-11 min-w-0 flex-col items-center justify-center gap-1 px-0.5 py-1 text-sm font-bold focus-visible:z-10 focus-visible:outline-offset-[-2px] sm:min-h-15',
                    value === selected ? 'bg-accent text-white' : 'bg-surface hover:bg-soft',
                    value === today && value !== selected && 'text-accent',
                  )}
                >
                  {day}
                  {count > 0 && <span className={cn('min-w-4 rounded px-1 text-[0.65rem] leading-4', value === selected ? 'bg-white/25' : 'bg-soft text-accent')}>{count}</span>}
                </button>
              )
            })}
          </div>
        </section>

        <section aria-labelledby="day-label" className="min-w-0 rounded-2xl border border-line bg-surface p-4 sm:p-5">
          <h2 id="day-label" className="text-lg font-extrabold">Задачи на {formatDay(selected)}</h2>
          {dailyTasks.length ? (
            <ul className="my-4 divide-y divide-line">
              {dailyTasks.map((task) => (
                <li key={task.id} className="py-2.5">
                  <button type="button" onClick={() => onEdit(task)} className="rounded-sm text-left text-sm font-bold break-words text-accent hover:underline">{task.title}</button>
                  <p className="mt-1 text-xs break-words text-muted">{task.subject} · {statuses.find((status) => status.id === task.status)?.name}</p>
                </li>
              ))}
            </ul>
          ) : <p className="my-4 text-sm text-muted">На этот день задач нет.</p>}
          <Button variant="secondary" onClick={() => onCreate(selected)}>Добавить на этот день</Button>
        </section>
      </div>
    </>
  )
}
