import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Button } from './shared/Button'
import { statuses, useTaskStore, type Task, type TaskValues } from './tasks'

const field = 'min-h-10 w-full rounded-lg border border-line bg-surface px-3 py-2 text-sm text-ink'

interface TaskDialogProps {
  task?: Task
  date: string
  onClose: () => void
}

export function TaskDialog({ task, date, onClose }: TaskDialogProps) {
  const [values, setValues] = useState<TaskValues>(() => task ? {
    title: task.title,
    subject: task.subject,
    date: task.date,
    notes: task.notes,
    status: task.status,
    priority: task.priority,
  } : {
    title: '', subject: '', date, notes: '', status: 'todo', priority: 'normal',
  })
  const [error, setError] = useState('')
  const dialog = useRef<HTMLDialogElement>(null)
  const { addTask, updateTask, removeTask } = useTaskStore()

  useEffect(() => {
    if (dialog.current && !dialog.current.open) dialog.current.showModal()
  }, [])

  function change<K extends keyof TaskValues>(fieldName: K, value: TaskValues[K]) {
    setValues((draft) => ({ ...draft, [fieldName]: value }))
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const clean = { ...values, title: values.title.trim(), subject: values.subject.trim(), notes: values.notes.trim() }
    if (!clean.title || !clean.subject) {
      setError('Введи название и предмет.')
      return
    }
    if (task) updateTask(task.id, clean)
    else addTask(clean)
    dialog.current?.close()
  }

  function remove() {
    if (!task || !window.confirm('Удалить эту задачу?')) return
    removeTask(task.id)
    dialog.current?.close()
  }

  return (
    <dialog
      ref={dialog}
      onClose={onClose}
      aria-labelledby="task-editor-title"
      className="m-auto max-h-[calc(100dvh_-_2rem)] w-[calc(100%_-_2rem)] max-w-lg overflow-auto rounded-2xl border border-line bg-surface p-5 text-ink shadow-xl backdrop:bg-slate-950/45 sm:p-6"
    >
      <h2 id="task-editor-title" className="mb-4 text-xl font-extrabold">{task ? 'Редактировать задачу' : 'Новая задача'}</h2>
      <form onSubmit={submit} className="grid gap-3.5">
        <label className="grid gap-1 text-sm font-semibold">
          Название
          <input required maxLength={100} value={values.title} onChange={(event) => change('title', event.currentTarget.value)} className={field} />
        </label>
        <label className="grid gap-1 text-sm font-semibold">
          Предмет
          <input required maxLength={50} value={values.subject} onChange={(event) => change('subject', event.currentTarget.value)} className={field} />
        </label>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="grid min-w-0 gap-1 text-sm font-semibold">
            Срок
            <input required type="date" value={values.date} onChange={(event) => change('date', event.currentTarget.value)} className={field} />
          </label>
          <div className="grid gap-1 text-sm font-semibold">
            <label htmlFor="task-status">Статус</label>
            <select
              id="task-status"
              value={values.status}
              onChange={(event) => {
                const status = statuses.find((option) => option.id === event.currentTarget.value)
                if (status) change('status', status.id)
              }}
              className={field}
            >
              {statuses.map((status) => <option key={status.id} value={status.id}>{status.name}</option>)}
            </select>
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm font-semibold">
          <input
            type="checkbox"
            checked={values.priority === 'high'}
            onChange={(event) => change('priority', event.currentTarget.checked ? 'high' : 'normal')}
            className="size-4 accent-accent"
          />
          Высокий приоритет
        </label>
        <div className="grid gap-1 text-sm font-semibold">
          <label htmlFor="task-notes">Заметка</label>
          <textarea id="task-notes" rows={3} maxLength={350} value={values.notes} onChange={(event) => change('notes', event.currentTarget.value)} className={field} />
        </div>
        {error && <p role="alert" className="text-sm font-semibold text-rose-700">{error}</p>}
        <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
          {task && <Button variant="quiet" className="mr-auto text-rose-700" onClick={remove}>Удалить</Button>}
          <Button variant="secondary" onClick={() => dialog.current?.close()}>Отмена</Button>
          <Button type="submit">Сохранить</Button>
        </div>
      </form>
    </dialog>
  )
}
