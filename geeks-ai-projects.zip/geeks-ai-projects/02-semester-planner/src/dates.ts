export function dateKey(date: Date) {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('-')
}

export function dateFromToday(offset: number) {
  const date = new Date()
  date.setDate(date.getDate() + offset)
  return dateKey(date)
}

export function getMonthCells(date: Date): (number | null)[] {
  const year = date.getFullYear()
  const month = date.getMonth()
  const offset = (new Date(year, month, 1).getDay() + 6) % 7
  const days = new Date(year, month + 1, 0).getDate()
  const cells = Math.ceil((offset + days) / 7) * 7

  return Array.from({ length: cells }, (_, index) => {
    const day = index - offset + 1
    return day >= 1 && day <= days ? day : null
  })
}

const dayFormatter = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' })

export function formatDay(value: string) {
  return dayFormatter.format(new Date(value + 'T12:00:00'))
}
