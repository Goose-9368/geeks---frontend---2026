import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { dateFromToday } from './dates'

export const statuses = [
  { id: 'todo', name: 'Запланировано' },
  { id: 'doing', name: 'В работе' },
  { id: 'done', name: 'Готово' },
] as const
export type TaskStatus = (typeof statuses)[number]['id']

export interface TaskValues {
  title: string
  subject: string
  date: string
  notes: string
  status: TaskStatus
  priority: 'normal' | 'high'
}

export interface Task extends TaskValues {
  id: string
}

const examples: Task[] = [
  {
    id: 'analysis',
    title: 'Повторить признаки сходимости рядов',
    subject: 'Матанализ',
    date: dateFromToday(2),
    notes: 'Решить по одному примеру на прямое и предельное сравнение.',
    status: 'todo',
    priority: 'high',
  },
  {
    id: 'ode',
    title: 'Решить три уравнения второго порядка',
    subject: 'Дифференциальные уравнения',
    date: dateFromToday(0),
    notes: 'Разобрать разные корни характеристического уравнения.',
    status: 'todo',
    priority: 'normal',
  },
  {
    id: 'mis',
    title: 'Собрать сводную таблицу',
    subject: 'MIS',
    date: dateFromToday(1),
    notes: 'Сравнить продажи по категориям и месяцам.',
    status: 'doing',
    priority: 'normal',
  },
  {
    id: 'english',
    title: 'Проверить тезис и план эссе',
    subject: 'Английский',
    date: dateFromToday(3),
    notes: 'Проверить, что каждый абзац поддерживает тезис.',
    status: 'doing',
    priority: 'high',
  },
  {
    id: 'frontend',
    title: 'Проверить адаптивную сетку',
    subject: 'Frontend',
    date: dateFromToday(-1),
    notes: 'Собраны варианты для телефона и большого экрана.',
    status: 'done',
    priority: 'normal',
  },
]

interface TaskStore {
  tasks: Task[]
  addTask: (values: TaskValues) => void
  updateTask: (id: string, values: TaskValues) => void
  setStatus: (id: string, status: TaskStatus) => void
  removeTask: (id: string) => void
}

export const useTaskStore = create<TaskStore>()(persist(
  (set) => ({
    tasks: examples,
    addTask: (values) => set((state) => ({
      tasks: [...state.tasks, { ...values, id: crypto.randomUUID() }],
    })),
    updateTask: (id, values) => set((state) => ({
      tasks: state.tasks.map((task) => task.id === id ? { ...values, id } : task),
    })),
    setStatus: (id, status) => set((state) => ({
      tasks: state.tasks.map((task) => task.id === id ? { ...task, status } : task),
    })),
    removeTask: (id) => set((state) => ({
      tasks: state.tasks.filter((task) => task.id !== id),
    })),
  }),
  { name: 'geeks-semester-tasks-v1', partialize: ({ tasks }) => ({ tasks }) },
))
