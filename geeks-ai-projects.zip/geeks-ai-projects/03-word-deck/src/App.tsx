import { useEffect, useState } from 'react'
import { Link, NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { DictionaryPage } from './DictionaryPage'
import { LearnPage } from './LearnPage'
import { QuizPage } from './QuizPage'
import { cn } from './shared/cn'
import { vocabulary } from './vocabulary'

const progressKey = 'geeks-word-deck-progress-v1'
const validIds = new Set(vocabulary.map((card) => card.id))
const navigation = [
  { path: '/cards', name: 'Карточки' },
  { path: '/quiz', name: 'Тест' },
  { path: '/dictionary', name: 'Словарь' },
]

function readProgress(): string[] {
  try {
    const data: unknown = JSON.parse(localStorage.getItem(progressKey) ?? '[]')
    if (Array.isArray(data)) {
      return [...new Set(data.filter((value): value is string => typeof value === 'string' && validIds.has(value)))]
    }
  } catch {
    return []
  }
  return []
}

export function App() {
  const [known, setKnown] = useState(readProgress)
  const { pathname } = useLocation()

  useEffect(() => {
    try {
      localStorage.setItem(progressKey, JSON.stringify(known))
    } catch {
      // Progress stays available for the current session.
    }
  }, [known])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  function changeKnown(id: string, value: boolean) {
    setKnown((current) => value ? [...new Set([...current, id])] : current.filter((item) => item !== id))
  }

  return (
    <div className="min-h-dvh">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-8">
          <Link to="/cards" className="inline-flex items-center gap-3 rounded-lg text-lg font-extrabold tracking-tight">
            <span aria-hidden="true" className="grid size-9 place-items-center rounded-xl bg-accent font-serif text-xl text-white">W</span>
            Word Deck
          </Link>
          <nav aria-label="Тренажёр" className="flex flex-wrap gap-1">
            {navigation.map(({ path, name }) => (
              <NavLink
                key={path}
                to={path}
                className={({ isActive }) => cn('rounded-lg px-3 py-2 text-sm font-bold', isActive ? 'bg-soft text-accent' : 'text-muted hover:bg-canvas')}
              >
                {name}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-4 py-7 sm:px-8 sm:py-10">
        <Routes>
          <Route path="/cards" element={<LearnPage known={known} onKnown={changeKnown} />} />
          <Route path="/quiz" element={<QuizPage />} />
          <Route path="/dictionary" element={<DictionaryPage known={known} />} />
          <Route path="*" element={<Navigate to="/cards" replace />} />
        </Routes>
      </main>
    </div>
  )
}
