import { useState } from 'react'
import { Button } from './shared/Button'
import { topics, vocabulary } from './vocabulary'

export function DictionaryPage({ known }: { known: readonly string[] }) {
  const [search, setSearch] = useState('')
  const [topic, setTopic] = useState('')
  const query = search.trim().toLocaleLowerCase()
  const results = vocabulary.filter((word) => (
    (!topic || word.topic === topic) &&
    (word.phrase + ' ' + word.translation).toLocaleLowerCase().includes(query)
  ))

  return (
    <>
      <h1 className="mb-6 text-3xl font-black tracking-tight sm:text-4xl">Словарь</h1>
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <label className="grid min-w-40 flex-1 gap-1 text-sm font-semibold sm:max-w-sm">
          Поиск
          <input
            type="search"
            placeholder="Фраза или перевод"
            value={search}
            onChange={(event) => setSearch(event.currentTarget.value)}
            className="min-h-10 rounded-lg border border-line bg-surface px-3 text-sm"
          />
        </label>
        <div className="grid gap-1 text-sm font-semibold">
          <label htmlFor="dictionary-topic">Тема</label>
          <select id="dictionary-topic" value={topic} onChange={(event) => setTopic(event.currentTarget.value)} className="min-h-10 rounded-lg border border-line bg-surface px-3 text-sm">
            <option value="">Все темы</option>
            {topics.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
          </select>
        </div>
        {(search || topic) && <Button variant="quiet" onClick={() => { setSearch(''); setTopic('') }}>Сбросить</Button>}
      </div>
      <p role="status" className="mb-3 text-sm font-semibold text-muted">Найдено {results.length} из {vocabulary.length}</p>
      {results.length ? (
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
          {results.map((word) => (
            <li key={word.id} className="grid min-w-0 gap-2 p-4 sm:grid-cols-[minmax(0,1fr)_minmax(0,0.85fr)] sm:gap-5 sm:px-6">
              <div>
                <p lang="en" className="font-serif text-xl font-bold">{word.phrase}</p>
                <p lang="en" className="mt-1 text-sm text-muted">{word.example}</p>
              </div>
              <div>
                <p className="text-sm font-bold">{word.translation}</p>
                <p className="mt-1 text-xs text-muted">
                  {topics.find((item) => item.id === word.topic)?.name}{known.includes(word.id) && ' · Выучено'}
                </p>
              </div>
            </li>
          ))}
        </ul>
      ) : <p className="rounded-xl border border-line bg-surface p-5 text-sm text-muted">По запросу ничего не найдено.</p>}
    </>
  )
}
