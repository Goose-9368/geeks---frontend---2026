import { useState } from 'react'
import { Button } from './shared/Button'
import { TopicSelect } from './TopicSelect'
import { topics, vocabulary, type TopicId } from './vocabulary'

interface LearnPageProps {
  known: readonly string[]
  onKnown: (id: string, value: boolean) => void
}

export function LearnPage({ known, onKnown }: LearnPageProps) {
  const [topic, setTopic] = useState<TopicId>('study')
  const [index, setIndex] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const deck = vocabulary.filter((card) => card.topic === topic)
  const card = deck[index]

  function showCard(next: number) {
    setIndex(next)
    setFlipped(false)
  }

  function mark(isKnown: boolean) {
    onKnown(card.id, isKnown)
    showCard(Math.min(index + 1, deck.length - 1))
  }

  return (
    <>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Карточки английского</h1>
          <p className="mt-2 text-sm text-muted">Переверни карточку, чтобы увидеть перевод.</p>
        </div>
        <TopicSelect value={topic} onChange={(value) => { setTopic(value); showCard(0) }} />
      </div>
      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_17rem]">
        <section aria-label="Тренировка" className="min-w-0 rounded-2xl border border-line bg-surface p-4 sm:p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-muted">
            <span>Карточка {index + 1} из {deck.length}</span>
            {known.includes(card.id) && <span className="rounded-full bg-soft px-2.5 py-1 text-accent">Выучено</span>}
          </div>
          <button
            type="button"
            onClick={() => setFlipped((value) => !value)}
            className="flex min-h-65 w-full flex-col items-center justify-center gap-3 rounded-2xl border border-line bg-gradient-to-br from-[#f9eae4] to-[#f1d9e6] p-5 text-center sm:min-h-72 sm:p-8"
          >
            <span
              lang={flipped ? 'ru' : 'en'}
              className="font-serif text-3xl leading-tight font-bold break-words sm:text-4xl"
            >
              {flipped ? card.translation : card.phrase}
            </span>
            <span lang="en" className="max-w-md text-sm leading-relaxed text-muted">{card.example}</span>
            <span className="mt-2 text-xs font-bold text-accent">{flipped ? 'Показать фразу' : 'Показать перевод'}</span>
          </button>
          <div className="mt-4 flex flex-wrap justify-between gap-3">
            <div className="flex flex-wrap gap-2">
              <Button variant="secondary" disabled={index === 0} onClick={() => showCard(index - 1)}>Назад</Button>
              <Button variant="secondary" disabled={index === deck.length - 1} onClick={() => showCard(index + 1)}>Вперёд</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="secondary" onClick={() => mark(false)}>На повторение</Button>
              <Button onClick={() => mark(true)}>Знаю</Button>
            </div>
          </div>
        </section>

        <section aria-labelledby="progress-heading" className="rounded-2xl border border-line bg-surface p-5">
          <h2 id="progress-heading" className="text-base font-extrabold">Прогресс</h2>
          <p className="mt-2 text-2xl font-black text-accent">{known.length} <span className="text-base font-bold text-muted">из {vocabulary.length}</span></p>
          <ul className="mt-5 grid gap-4">
            {topics.map(({ id, name }) => {
              const cards = vocabulary.filter((word) => word.topic === id)
              const done = cards.filter((word) => known.includes(word.id)).length
              return (
                <li key={id}>
                  <div className="mb-1.5 flex justify-between gap-2 text-sm font-semibold"><span>{name}</span><span className="text-muted">{done} / {cards.length}</span></div>
                  <div
                    role="progressbar"
                    aria-label={name}
                    aria-valuemin={0}
                    aria-valuemax={cards.length}
                    aria-valuenow={done}
                    className="h-2 overflow-hidden rounded-full bg-soft"
                  >
                    <div style={{ width: (done / cards.length) * 100 + '%' }} className="h-full rounded-full bg-accent" />
                  </div>
                </li>
              )
            })}
          </ul>
        </section>
      </div>
    </>
  )
}
