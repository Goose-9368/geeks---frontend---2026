import { useState } from 'react'
import { Button } from './shared/Button'
import { cn } from './shared/cn'
import { TopicSelect } from './TopicSelect'
import { vocabulary, type TopicId } from './vocabulary'

function shuffle<T>(items: readonly T[]): T[] {
  const shuffled = [...items]
  for (let index = shuffled.length - 1; index > 0; index--) {
    const next = Math.floor(Math.random() * (index + 1))
    const card = shuffled[index]
    shuffled[index] = shuffled[next]
    shuffled[next] = card
  }
  return shuffled
}

function createQuestions(topic: TopicId) {
  const deck = vocabulary.filter((card) => card.topic === topic)
  return shuffle(deck).map((card) => ({
    card,
    answers: shuffle([card, ...shuffle(deck.filter((other) => other.id !== card.id)).slice(0, 3)]),
  }))
}

function QuizRound({ topic }: { topic: TopicId }) {
  const [questions, setQuestions] = useState(() => createQuestions(topic))
  const [index, setIndex] = useState(0)
  const [answer, setAnswer] = useState<string | null>(null)
  const [score, setScore] = useState(0)
  const question = questions[index]

  function retry() {
    setQuestions(createQuestions(topic))
    setIndex(0)
    setAnswer(null)
    setScore(0)
  }

  if (!question) {
    return (
      <section aria-labelledby="quiz-result" className="rounded-2xl border border-line bg-surface p-6 sm:p-8">
        <h2 id="quiz-result" className="text-xl font-extrabold">Результат теста</h2>
        <p className="mt-3 text-3xl font-black text-accent">{score} из {questions.length}</p>
        <p className="mt-2 text-sm text-muted">Правильных ответов</p>
        <Button className="mt-5" onClick={retry}>Пройти ещё раз</Button>
      </section>
    )
  }

  return (
    <section aria-label="Вопрос теста" className="rounded-2xl border border-line bg-surface p-5 sm:p-7">
      <p className="text-sm font-bold text-muted">Вопрос {index + 1} из {questions.length}</p>
      <h2 lang="en" className="mt-2 font-serif text-3xl leading-tight font-bold sm:text-4xl">{question.card.phrase}</h2>
      <div className="mt-5 grid gap-2 sm:grid-cols-2">
        {question.answers.map((option) => {
          const correct = answer !== null && option.id === question.card.id
          const wrong = answer === option.id && !correct
          return (
            <button
              key={option.id}
              type="button"
              disabled={answer !== null}
              onClick={() => {
                setAnswer(option.id)
                if (option.id === question.card.id) setScore((value) => value + 1)
              }}
              className={cn(
                'min-h-13 rounded-xl border p-3 text-left text-sm font-semibold',
                correct ? 'border-green-500 bg-green-50 text-green-900' :
                  wrong ? 'border-rose-400 bg-rose-50 text-rose-900' : 'border-line bg-canvas enabled:hover:bg-soft',
              )}
            >
              {option.translation}
            </button>
          )
        })}
      </div>
      {answer !== null && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <p role="status" className="text-sm font-bold text-muted">
            {answer === question.card.id ? 'Верно!' : 'Правильный ответ — ' + question.card.translation}
          </p>
          <Button onClick={() => { setIndex(index + 1); setAnswer(null) }}>
            {index === questions.length - 1 ? 'Показать результат' : 'Следующий вопрос'}
          </Button>
        </div>
      )}
    </section>
  )
}

export function QuizPage() {
  const [topic, setTopic] = useState<TopicId>('study')
  return (
    <>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Тест по словам</h1>
          <p className="mt-2 text-sm text-muted">Выбери перевод для каждой английской фразы.</p>
        </div>
        <TopicSelect value={topic} onChange={setTopic} />
      </div>
      <QuizRound key={topic} topic={topic} />
    </>
  )
}
