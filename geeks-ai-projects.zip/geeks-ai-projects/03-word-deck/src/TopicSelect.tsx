import { topics, type TopicId } from './vocabulary'

export function TopicSelect({ value, onChange }: { value: TopicId; onChange: (topic: TopicId) => void }) {
  return (
    <div className="grid gap-1 text-sm font-semibold">
      <label htmlFor="practice-topic">Тема</label>
      <select
        id="practice-topic"
        value={value}
        onChange={(event) => {
          const topic = topics.find((item) => item.id === event.currentTarget.value)
          if (topic) onChange(topic.id)
        }}
        className="min-h-10 rounded-lg border border-line bg-surface px-3 text-sm"
      >
        {topics.map((topic) => <option key={topic.id} value={topic.id}>{topic.name}</option>)}
      </select>
    </div>
  )
}
