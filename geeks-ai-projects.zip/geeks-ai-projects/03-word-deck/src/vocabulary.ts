export const topics = [
  { id: 'study', name: 'Учёба' },
  { id: 'work', name: 'Работа' },
  { id: 'daily', name: 'Общение' },
] as const
export type TopicId = (typeof topics)[number]['id']

export interface WordCard {
  id: string
  topic: TopicId
  phrase: string
  translation: string
  example: string
}

export const vocabulary: WordCard[] = [
  {
    id: 'hand-in', topic: 'study', phrase: 'hand in an assignment', translation: 'сдать задание',
    example: 'We need to hand in the assignment by Friday.',
  },
  {
    id: 'notes', topic: 'study', phrase: 'take notes', translation: 'делать заметки',
    example: 'I take notes while I watch the lecture.',
  },
  {
    id: 'deadline', topic: 'study', phrase: 'meet a deadline', translation: 'уложиться в срок',
    example: 'We finished early and met the deadline.',
  },
  {
    id: 'look-up', topic: 'study', phrase: 'look up a word', translation: 'найти слово в словаре',
    example: 'I looked up the word before using it.',
  },
  {
    id: 'catch-up', topic: 'study', phrase: 'catch up on lessons', translation: 'наверстать пропущенные уроки',
    example: 'I spent Saturday catching up on my lessons.',
  },
  {
    id: 'review', topic: 'study', phrase: 'review for an exam', translation: 'повторять материал к экзамену',
    example: 'We reviewed for the exam together.',
  },
  {
    id: 'follow-up', topic: 'work', phrase: 'follow up', translation: 'вернуться к обсуждению',
    example: 'I’ll follow up with you after the meeting.',
  },
  {
    id: 'feedback', topic: 'work', phrase: 'give feedback', translation: 'дать обратную связь',
    example: 'Could you give me feedback on my draft?',
  },
  {
    id: 'meeting', topic: 'work', phrase: 'set up a meeting', translation: 'назначить встречу',
    example: 'Let’s set up a meeting for tomorrow.',
  },
  {
    id: 'remote', topic: 'work', phrase: 'work remotely', translation: 'работать удалённо',
    example: 'I work remotely two days a week.',
  },
  {
    id: 'update', topic: 'work', phrase: 'share an update', translation: 'сообщить о ходе работы',
    example: 'I’ll share an update on the project this afternoon.',
  },
  {
    id: 'responsibility', topic: 'work', phrase: 'take responsibility', translation: 'взять на себя ответственность',
    example: 'She took responsibility for fixing the issue.',
  },
  {
    id: 'repeat', topic: 'daily', phrase: 'Could you repeat that?', translation: 'Не могли бы вы повторить?',
    example: 'I didn’t hear the last part. Could you repeat that?',
  },
  {
    id: 'agree', topic: 'daily', phrase: 'I agree.', translation: 'Я согласен / согласна.',
    example: 'I agree. Let’s try it your way.',
  },
  {
    id: 'understand', topic: 'daily', phrase: 'I don’t understand yet.', translation: 'Я пока не понимаю.',
    example: 'I don’t understand yet. Can you give me an example?',
  },
  {
    id: 'works', topic: 'daily', phrase: 'That works for me.', translation: 'Мне это подходит.',
    example: 'Can we meet at six? That works for me.',
  },
  {
    id: 'way', topic: 'daily', phrase: 'I’m on my way.', translation: 'Я уже в пути.',
    example: 'I’m on my way. I’ll be there in ten minutes.',
  },
  {
    id: 'let-me-know', topic: 'daily', phrase: 'Let me know.', translation: 'Дай мне знать.',
    example: 'Let me know when you get home.',
  },
]
