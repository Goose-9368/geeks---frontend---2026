export type Book = {
  id: number;
  title: string;
  author: string;
  rating?: number;
};

export type Library = {
  books: Book[];
};

export function addBook(library: Library, book: Book): Library {
  return {
    ...library,
    books: [...library.books, book],
  };
}

export function getAverageRating(books: Book[]): number {
  let totalRating = 0;
  let ratedBookCount = 0;

  for (const book of books) {
    const rating = book.rating;

    if (rating !== undefined) {
      totalRating += rating;
      ratedBookCount += 1;
    }
  }

  if (ratedBookCount === 0) {
    return 0;
  }

  return totalRating / ratedBookCount;
}
