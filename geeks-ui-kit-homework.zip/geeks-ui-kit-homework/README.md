# Geeks · UI Kit

Домашняя работа к уроку 64. К `Button` из проекта урока добавлены три переиспользуемых компонента на React, TypeScript и Tailwind CSS. В `src/App.tsx` есть примеры всех четырёх компонентов.

## Запуск

Используй Node.js 24 LTS. Открой терминал в папке с `package.json` и выполни команды.

```bash
npm ci
npm run dev
```

Vite покажет адрес страницы. Команда `npm run build` проверяет типы и собирает проект. Команда `npm run lint` запускает проверку кода.

## Компоненты

| Компонент | Варианты | Размеры | Дополнительные пропсы |
| --- | --- | --- | --- |
| `Input` | `outline`, `filled` | `sm`, `md`, `lg` | `label`, `hint`, `error`, `fullWidth` |
| `Badge` | `neutral`, `primary`, `success`, `warning`, `danger` | `sm`, `md` | `children` для текста бейджа |
| `Card` | `outline`, `elevated`, `subtle` | `sm`, `md`, `lg` | `header`, `children`, `footer` |

У каждого компонента есть интерфейс пропсов, таблицы классов `VARIANTS` и `SIZES` и утилита `cn` для объединения классов. Стандартные HTML-пропсы, например `name`, `disabled` или `onChange`, передаются соответствующему элементу. Общие цвета и скругления заданы в `src/index.css`.

У поля ввода подпись связана с полем через `htmlFor` и `id`. При ошибке `Input` показывает текст ошибки вместо подсказки и устанавливает `aria-invalid`.

```tsx
import { Badge, Card, Input } from './shared/ui'

<Card
  variant="elevated"
  header={<h2>Профиль</h2>}
  footer={<Badge variant="success">Черновик сохранён</Badge>}
>
  <Input label="Имя" name="name" fullWidth />
</Card>
```

## GitHub

Распакуй ZIP и загрузи содержимое папки `geeks-ui-kit-homework` в свой репозиторий. Файл `package.json` должен оказаться в корне репозитория.

Исходный проект преподавателя. [64-ui-kit](https://github.com/Temirlan002/64-ui-kit)
