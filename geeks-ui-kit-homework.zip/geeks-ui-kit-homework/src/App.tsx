import { useState } from 'react'
import { Badge, Button, Card, Input } from './shared/ui'

const sections = ['Input', 'Button', 'Badge', 'Card']
const buttonVariants = [
  { variant: 'primary', label: 'Primary' },
  { variant: 'secondary', label: 'Secondary' },
  { variant: 'danger', label: 'Danger' },
  { variant: 'ghost', label: 'Ghost' },
] as const

const panelClassName = 'rounded-card border border-border bg-surface p-5 sm:p-6'

function App() {
  const [emailInvalid, setEmailInvalid] = useState(true)
  const [activeButton, setActiveButton] = useState('')

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-foreground antialiased">
      <header id="top" className="border-b border-border bg-surface">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-8 gap-y-3 px-5 py-4 sm:px-8">
          <a href="#top" className="inline-flex items-center gap-3 text-sm font-semibold">
            <span aria-hidden="true" className="flex size-9 items-center justify-center rounded-control bg-primary-600 text-xs font-bold text-white">
              UI
            </span>
            Geeks · Урок 64
          </a>
          <nav aria-label="Компоненты" className="flex flex-wrap gap-x-5 gap-y-2 text-sm font-medium text-muted sm:gap-x-7">
            {sections.map((section) => (
              <a key={section} href={'#' + section.toLowerCase()} className="hover:text-primary-700 hover:underline">
                {section}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-5 px-5 py-9 sm:px-8 sm:py-12">
        <div className="pb-3">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">UI Kit</h1>
          <p className="mt-3 text-base text-muted">Варианты, размеры и состояния компонентов на React и TypeScript.</p>
        </div>

        <section id="input" aria-labelledby="input-title" className={panelClassName}>
          <h2 id="input-title" className="mb-5 text-xl font-semibold">Input</h2>
          <div className="grid items-start gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Input label="Имя" name="name" autoComplete="given-name" placeholder="Алия" fullWidth />
            <Input label="Поиск" name="search" type="search" placeholder="Найти компонент" variant="filled" size="sm" fullWidth />
            <Input
              label="Электронная почта"
              name="email"
              type="email"
              autoComplete="email"
              defaultValue="student"
              size="lg"
              hint="Например, student@example.com."
              error={emailInvalid ? 'Введи адрес в формате student@example.com.' : undefined}
              onChange={(event) => setEmailInvalid(event.currentTarget.validity.typeMismatch)}
              fullWidth
            />
            <Input label="Номер группы" name="group" defaultValue="64" disabled fullWidth />
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
          <section id="button" aria-labelledby="button-title" className={panelClassName}>
            <h2 id="button-title" className="mb-5 text-xl font-semibold">Button</h2>
            <div className="flex flex-wrap items-center gap-2">
              {buttonVariants.map(({ variant, label }) => (
                <Button key={variant} variant={variant} onClick={() => setActiveButton(label)}>
                  {label}
                </Button>
              ))}
              <Button variant="secondary" isLoading>Загрузка</Button>
            </div>
            <p role="status" className="mt-4 text-sm text-muted">
              {activeButton ? 'Нажата кнопка ' + activeButton + '.' : 'Нажми любую активную кнопку.'}
            </p>
          </section>

          <section id="badge" aria-labelledby="badge-title" className={panelClassName}>
            <h2 id="badge-title" className="mb-5 text-xl font-semibold">Badge</h2>
            <div className="flex flex-wrap items-center gap-2">
              <Badge size="sm">Черновик</Badge>
              <Badge variant="primary">Новый</Badge>
              <Badge variant="success">Готово</Badge>
              <Badge variant="warning">На проверке</Badge>
              <Badge variant="danger">Ошибка</Badge>
            </div>
          </section>
        </div>

        <section id="card" aria-labelledby="card-title" className="pt-2">
          <h2 id="card-title" className="mb-4 text-xl font-semibold">Card</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <Card
              size="sm"
              header={<h3 className="text-base font-semibold">С обводкой</h3>}
              footer={<code className="text-xs text-primary-700">variant="outline"</code>}
            >
              <p className="text-sm text-muted">Базовый вариант для блока с информацией.</p>
            </Card>
            <Card
              variant="elevated"
              header={<h3 className="text-base font-semibold">С тенью</h3>}
              footer={<code className="text-xs text-primary-700">variant="elevated"</code>}
            >
              <p className="text-sm text-muted">Тень выделяет карточку на фоне страницы.</p>
            </Card>
            <Card
              variant="subtle"
              size="lg"
              header={<h3 className="text-base font-semibold">С заливкой</h3>}
              footer={<code className="text-xs text-primary-700">variant="subtle"</code>}
            >
              <p className="text-sm text-muted">Мягкий фон подходит для заметок и подсказок.</p>
            </Card>
          </div>
        </section>
      </main>
    </div>
  )
}

export default App
