import type { ComponentProps } from 'react'
import { cn } from '../../lib/cn'

type BadgeVariant = 'neutral' | 'primary' | 'success' | 'warning' | 'danger'
type BadgeSize = 'sm' | 'md'

const VARIANTS: Record<BadgeVariant, string> = {
    neutral: 'bg-slate-100 text-slate-700',
    primary: 'bg-primary-50 text-primary-700',
    success: 'bg-success-50 text-green-800',
    warning: 'bg-warning-50 text-amber-800',
    danger: 'bg-danger-50 text-red-800',
}

const SIZES: Record<BadgeSize, string> = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
}

export interface BadgeProps extends ComponentProps<'span'> {
    variant?: BadgeVariant
    size?: BadgeSize
}

export function Badge({
    variant = 'neutral',
    size = 'md',
    className,
    ...props
}: BadgeProps) {
    return (
        <span
            {...props}
            className={cn(
                'inline-flex w-fit items-center rounded-full font-semibold',
                VARIANTS[variant],
                SIZES[size],
                className,
            )}
        />
    )
}
