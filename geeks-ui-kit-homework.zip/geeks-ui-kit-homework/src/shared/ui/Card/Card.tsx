import type { ComponentProps, ReactNode } from 'react'
import { cn } from '../../lib/cn'

type CardVariant = 'outline' | 'elevated' | 'subtle'
type CardSize = 'sm' | 'md' | 'lg'

const VARIANTS: Record<CardVariant, string> = {
    outline: 'border-border bg-surface',
    elevated: 'border-border bg-surface shadow-lg shadow-slate-900/10',
    subtle: 'border-primary-100 bg-primary-50',
}

const SIZES: Record<CardSize, string> = {
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
}

export interface CardProps extends ComponentProps<'article'> {
    variant?: CardVariant
    size?: CardSize
    header?: ReactNode
    footer?: ReactNode
}

export function Card({
    variant = 'outline',
    size = 'md',
    header,
    footer,
    children,
    className,
    ...props
}: CardProps) {
    return (
        <article
            {...props}
            className={cn(
                'flex min-w-0 flex-col gap-3 rounded-card border text-foreground',
                VARIANTS[variant],
                SIZES[size],
                className,
            )}
        >
            {header != null && <header>{header}</header>}
            {children}
            {footer != null && <footer className="mt-auto pt-2">{footer}</footer>}
        </article>
    )
}
