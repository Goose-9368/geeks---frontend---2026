import { useId, type ComponentProps } from 'react'
import { cn } from '../../lib/cn'

type InputVariant = 'outline' | 'filled'
type InputSize = 'sm' | 'md' | 'lg'

const VARIANTS: Record<InputVariant, string> = {
    outline: 'border-border bg-surface',
    filled: 'border-transparent bg-slate-100',
}

const SIZES: Record<InputSize, string> = {
    sm: 'h-8 px-3 text-sm',
    md: 'h-10 px-3 text-sm',
    lg: 'h-12 px-4 text-base',
}

export interface InputProps extends Omit<ComponentProps<'input'>, 'size'> {
    variant?: InputVariant
    size?: InputSize
    label?: string
    hint?: string
    error?: string
    fullWidth?: boolean
}

export function Input({
    variant = 'outline',
    size = 'md',
    label,
    hint,
    error,
    fullWidth = false,
    id,
    className,
    'aria-describedby': describedBy,
    'aria-invalid': invalid,
    ...props
}: InputProps) {
    const generatedId = useId()
    const inputId = id ?? generatedId
    const feedback = error || hint
    const feedbackId = feedback ? inputId + '-feedback' : undefined
    const descriptionIds = [describedBy, feedbackId].filter(Boolean).join(' ')

    return (
        <div className={cn('inline-flex min-w-0 max-w-full flex-col gap-1.5', fullWidth && 'w-full')}>
            {label && (
                <label htmlFor={inputId} className="text-sm font-medium text-foreground">
                    {label}
                </label>
            )}
            <input
                {...props}
                id={inputId}
                aria-describedby={descriptionIds || undefined}
                aria-invalid={error ? true : invalid}
                className={cn(
                    'min-w-0 w-full rounded-control border text-foreground placeholder:text-muted',
                    'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500',
                    'aria-invalid:border-danger-600 aria-invalid:focus-visible:outline-danger-600',
                    'disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-muted',
                    VARIANTS[variant],
                    SIZES[size],
                    className,
                )}
            />
            {feedback && (
                <p id={feedbackId} className={cn('text-sm', error ? 'text-danger-600' : 'text-muted')}>
                    {feedback}
                </p>
            )}
        </div>
    )
}
