# Grid-галерея раскладок

Учебный проект Geeks на React, TypeScript, Tailwind CSS и Vite. У каждой раскладки свой адрес с `#`. Ссылки работают и при размещении проекта в подпапке.

## Запуск

С Node.js 22.12 или новее открой папку с `package.json` и выполни команды.

```bash
npm ci
npm run dev
```

Vite покажет локальный адрес. Команда `npm run build` проверяет типы и собирает проект в `dist`.

## Раскладки

| Страница | Реализация |
| --- | --- |
| Каркас · `#/shell` | Общий каркас в `App.tsx`. Строки `auto 1fr auto` удерживают подвал внизу на коротких страницах. На узком экране сайдбар скрывается, а навигация доступна в шапке. |
| Каталог · `#/catalog` | 12 карточек и 1, 2, 3 или 4 колонки через `sm`, `lg` и `xl`. Правило `auto-rows-fr` выравнивает высоту рядов, Flexbox и `mt-auto` прижимают кнопки к низу карточек. |
| Auto-fill / auto-fit · `#/auto` | Тот же набор фотографий. Переключатель показывает 2, 6 или 12 карточек. Колонки создаются через `repeat()` и `minmax()` без брейкпоинтов. |
| Дашборд · `#/dashboard` | 7 блоков. С ширины `md` диаграмма занимает две строки и две колонки, темы занимают три колонки. На телефоне блоки идут столбцом. |
| Календарь · `#/calendar` | Месяц и сегодняшняя дата берутся из локального времени браузера. Формула `(getDay() + 6) % 7` переводит первый день месяца в сетку, которая начинается с понедельника. |

Чтобы увидеть разницу между `auto-fill` и `auto-fit`, оставь две карточки на широком экране и нажми кнопку переключения режима. `Auto-fill` оставляет место под пустые колонки. `Auto-fit` сворачивает их и отдаёт освободившуюся ширину карточкам.

## GitHub

Распакуй архив и загрузи содержимое папки `grid-gallery` в репозиторий. Файл `package.json` должен оказаться в корне репозитория.

## Фото

Фотографии входят в проект.

| Снимок | Источник |
| --- | --- |
| Горное озеро | [Pexels](https://www.pexels.com/photo/forest-by-turquoise-lake-in-mountains-18036188/) |
| Песчаные дюны | [Pexels](https://www.pexels.com/photo/serene-sand-dunes-at-sunset-with-ripples-33442715/) |
| Лес в тумане | [Pexels](https://www.pexels.com/photo/foggy-pine-forest-in-misty-landscape-34720637/) |
| Скалистый берег | [Pexels](https://www.pexels.com/photo/aerial-view-of-ocean-waves-along-rocky-coastline-30302406/) |
| Водопад | [Pexels](https://www.pexels.com/photo/water-falls-cascading-on-a-mossy-cliff-6373065/) |
| Каньон Антилопы | [Pexels](https://www.pexels.com/photo/stunning-curved-sandstone-layers-in-antelope-canyon-33240937/) |
| Снежная вершина | [Pexels](https://www.pexels.com/photo/snowy-mountain-peak-at-sunset-with-pink-glare-33653968/) |
| Река в долине | [Pexels](https://www.pexels.com/photo/river-between-green-mountains-1645850/) |
| Осенняя тропа | [Pexels](https://www.pexels.com/photo/autumn-forest-path-with-vibrant-foliage-29044360/) |
| Поле лаванды | [Pexels](https://www.pexels.com/photo/purple-lavender-on-field-during-sunset-723880/) |
| Северное сияние | [Pexels](https://www.pexels.com/photo/scenic-view-of-the-northern-lights-15297825/) |
| Холмы Тосканы | [Pexels](https://www.pexels.com/photo/picturesque-tuscan-landscape-at-sunrise-29990364/) |
