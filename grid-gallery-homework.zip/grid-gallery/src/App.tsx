import { useEffect } from 'react'
import clsx from 'clsx'
import { Link, Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom'
import { CalendarPage } from './pages/CalendarPage'
import { AutoCatalogPage, CatalogPage } from './pages/CatalogPage'
import { DashboardPage } from './pages/DashboardPage'
import { ShellPage } from './pages/ShellPage'

const layouts = [
  { path: '/shell', label: 'Каркас' },
  { path: '/catalog', label: 'Каталог' },
  { path: '/auto', label: 'Auto-fill / auto-fit' },
  { path: '/dashboard', label: 'Дашборд' },
  { path: '/calendar', label: 'Календарь' },
]

function LayoutNavigation({ compact = false }: { compact?: boolean }) {
  return (
    <nav aria-label="Раскладки">
      <ul className={compact ? 'flex flex-wrap gap-1' : 'grid gap-1'}>
        {layouts.map(({ path, label }) => (
          <li key={path}>
            <NavLink
              to={path}
              className={({ isActive }) => clsx(
                'block rounded-lg px-3 py-2 text-sm font-bold',
                isActive ? 'bg-accent-tint text-accent' : 'text-muted hover:bg-canvas hover:text-ink',
              )}
            >
              {label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  )
}

export function App() {
  const { pathname } = useLocation()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return (
    <div className="grid min-h-dvh grid-rows-[auto_1fr_auto]">
      <header className="border-b border-stroke bg-panel">
        <div className="mx-auto max-w-[90rem] px-4 sm:px-7 lg:px-10">
          <Link to="/catalog" className="inline-flex items-center gap-3 rounded-lg py-4 text-lg font-extrabold tracking-tight">
            <span aria-hidden="true" className="grid size-8 grid-cols-2 gap-0.5 rounded-lg bg-accent p-1.5">
              <span className="rounded-[2px] bg-white" />
              <span className="rounded-[2px] bg-white/55" />
              <span className="rounded-[2px] bg-white/55" />
              <span className="rounded-[2px] bg-white" />
            </span>
            Grid-галерея
          </Link>
          <div className="border-t border-stroke py-2.5 lg:hidden">
            <LayoutNavigation compact />
          </div>
        </div>
      </header>

      <div className="mx-auto grid w-full max-w-[90rem] grid-cols-1 items-start gap-7 px-4 py-7 sm:px-7 sm:py-9 lg:grid-cols-[12.5rem_minmax(0,1fr)] lg:px-10">
        <aside aria-label="Боковая панель" className="sticky top-6 hidden rounded-2xl border border-stroke bg-panel p-3 lg:block">
          <p className="px-3 pt-2 pb-2.5 text-xs font-extrabold tracking-wider text-muted uppercase">Раскладки</p>
          <LayoutNavigation />
        </aside>

        <main className="min-w-0">
          <Routes>
            <Route path="/shell" element={<ShellPage />} />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route path="/auto" element={<AutoCatalogPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="*" element={<Navigate to="/catalog" replace />} />
          </Routes>
        </main>
      </div>

      <footer className="border-t border-stroke bg-panel">
        <div className="mx-auto max-w-[90rem] px-4 py-4 text-sm font-semibold text-muted sm:px-7 lg:px-10">
          Учебный проект Geeks
        </div>
      </footer>
    </div>
  )
}
