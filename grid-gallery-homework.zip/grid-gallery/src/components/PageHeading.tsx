interface PageHeadingProps {
  title: string
  description: string
}

export function PageHeading({ title, description }: PageHeadingProps) {
  return (
    <div className="mb-6 sm:mb-7">
      <h1 className="text-[clamp(2.1rem,4vw,3.2rem)] leading-tight font-extrabold tracking-[-0.05em]">
        {title}
      </h1>
      <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted sm:text-base">
        {description}
      </p>
    </div>
  )
}
