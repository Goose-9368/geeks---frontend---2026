import { useEffect, useRef, useState, type CSSProperties } from 'react'
import clsx from 'clsx'
import type { Photo } from '../photos'

interface PhotoGalleryProps {
  items: readonly Photo[]
  className?: string
  style?: CSSProperties
}

export function PhotoGallery({ items, className, style }: PhotoGalleryProps) {
  const [selected, setSelected] = useState<Photo | null>(null)
  const dialog = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    if (selected && dialog.current && !dialog.current.open) {
      dialog.current.showModal()
    }
  }, [selected])

  return (
    <>
      <ul aria-label="Фотографии" className={clsx('grid auto-rows-fr gap-4', className)} style={style}>
        {items.map((photo) => (
          <li key={photo.id} className="min-w-0">
            <article className="flex h-full flex-col overflow-hidden rounded-2xl border border-stroke bg-panel">
              <img
                src={photo.image}
                alt={photo.alt}
                loading="lazy"
                className="aspect-[16/10] w-full bg-accent-tint object-cover"
              />
              <div className="flex flex-1 flex-col p-4">
                <p className="text-xs font-extrabold tracking-wider text-accent uppercase">{photo.category}</p>
                <h2 className="mt-1.5 text-lg leading-tight font-extrabold tracking-tight">{photo.title}</h2>
                <p className="mt-2 mb-4 text-sm leading-relaxed text-muted">{photo.description}</p>
                <button
                  type="button"
                  className="mt-auto flex min-h-10 items-center justify-between gap-2 rounded-lg border border-stroke px-3 py-2 text-left text-sm font-bold text-ink hover:border-accent-soft hover:bg-accent-tint hover:text-accent"
                  onClick={() => setSelected(photo)}
                >
                  <span>Смотреть фото<span className="sr-only"> «{photo.title}»</span></span>
                  <span aria-hidden="true">↗</span>
                </button>
              </div>
            </article>
          </li>
        ))}
      </ul>

      <dialog
        ref={dialog}
        onClose={() => setSelected(null)}
        aria-labelledby="photo-dialog-title"
        className="m-auto max-h-[calc(100dvh_-_2rem)] w-[calc(100%_-_2rem)] max-w-2xl overflow-auto rounded-2xl border border-stroke bg-panel text-ink shadow-xl backdrop:bg-ink/65"
      >
        {selected && (
          <>
            <img src={selected.image} alt={selected.alt} className="max-h-[58dvh] w-full bg-canvas object-contain" />
            <div className="p-5 sm:p-6">
              <h2 id="photo-dialog-title" className="text-2xl font-extrabold">{selected.title}</h2>
              <p className="mt-2 text-sm text-muted">{selected.description}</p>
              <form method="dialog" className="mt-4">
                <button type="submit" className="rounded-lg bg-accent px-4 py-2 text-sm font-bold text-white hover:bg-accent-hover">
                  Закрыть
                </button>
              </form>
            </div>
          </>
        )}
      </dialog>
    </>
  )
}
