export function getMonthCells(today: Date): (number | null)[] {
  const year = today.getFullYear()
  const month = today.getMonth()
  const firstWeekday = new Date(year, month, 1).getDay()
  const mondayOffset = (firstWeekday + 6) % 7
  const numberOfDays = new Date(year, month + 1, 0).getDate()
  const cellCount = Math.ceil((mondayOffset + numberOfDays) / 7) * 7

  return Array.from({ length: cellCount }, (_, index) => {
    const day = index - mondayOffset + 1
    return day >= 1 && day <= numberOfDays ? day : null
  })
}
