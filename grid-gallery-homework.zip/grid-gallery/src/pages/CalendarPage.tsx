import clsx from 'clsx'
import { PageHeading } from '../components/PageHeading'
import { getMonthCells } from '../lib/calendar'

const weekdays = [
  { short: 'Пн', name: 'Понедельник' },
  { short: 'Вт', name: 'Вторник' },
  { short: 'Ср', name: 'Среда' },
  { short: 'Чт', name: 'Четверг' },
  { short: 'Пт', name: 'Пятница' },
  { short: 'Сб', name: 'Суббота' },
  { short: 'Вс', name: 'Воскресенье' },
]

const monthFormatter = new Intl.DateTimeFormat('ru-RU', { month: 'long' })
const todayFormatter = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' })

export function CalendarPage() {
  const today = new Date()
  const year = today.getFullYear()
  const month = monthFormatter.format(today)
  const monthTitle = month[0].toUpperCase() + month.slice(1) + ' ' + year
  const isoMonth = year + '-' + String(today.getMonth() + 1).padStart(2, '0')
  const cells = getMonthCells(today)

  return (
    <>
      <PageHeading title="Календарь" description="Текущий месяц. Неделя начинается с понедельника." />
      <section aria-labelledby="month-title" className="overflow-hidden rounded-2xl border border-stroke bg-panel">
        <div className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
          <h2 id="month-title" className="text-xl font-extrabold tracking-tight sm:text-2xl">{monthTitle}</h2>
          <p className="inline-flex items-center gap-2 text-xs font-bold text-accent sm:text-sm">
            <span aria-hidden="true" className="size-2 rounded-full bg-accent" />
            Сегодня, {todayFormatter.format(today)}
          </p>
        </div>
        <div role="group" aria-label="Дни месяца" className="grid grid-cols-7 gap-px border-t border-stroke bg-stroke">
          {weekdays.map(({ short, name }) => (
            <div key={short} className="bg-canvas p-2 text-center text-xs font-extrabold text-muted sm:py-3 sm:text-sm">
              <abbr title={name} className="no-underline">{short}</abbr>
            </div>
          ))}
          {cells.map((day, index) => {
            const isToday = day === today.getDate()
            return (
              <div
                key={index}
                aria-hidden={day === null || undefined}
                className={clsx('flex min-h-11 items-center justify-center sm:min-h-17', day === null ? 'bg-canvas' : 'bg-panel')}
              >
                {day !== null && (
                  <time
                    dateTime={isoMonth + '-' + String(day).padStart(2, '0')}
                    aria-current={isToday ? 'date' : undefined}
                    className={clsx(
                      'flex size-8 items-center justify-center rounded-lg text-sm font-bold sm:size-9',
                      isToday && 'bg-accent text-white',
                    )}
                  >
                    {day}
                  </time>
                )}
              </div>
            )
          })}
        </div>
      </section>
    </>
  )
}
