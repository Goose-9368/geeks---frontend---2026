import { useState } from 'react'
import clsx from 'clsx'
import { PageHeading } from '../components/PageHeading'
import { PhotoGallery } from '../components/PhotoGallery'
import { photos } from '../photos'

const cardCounts = [2, 6, 12] as const
type CardCount = (typeof cardCounts)[number]
type AutoMode = 'auto-fill' | 'auto-fit'

export function CatalogPage() {
  return (
    <>
      <PageHeading
        title="Каталог"
        description="12 пейзажей. Число колонок меняется с 1 до 4 на брейкпоинтах."
      />
      <PhotoGallery items={photos} className="grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" />
    </>
  )
}

export function AutoCatalogPage() {
  const [count, setCount] = useState<CardCount>(2)
  const [mode, setMode] = useState<AutoMode>('auto-fill')
  const nextMode = mode === 'auto-fill' ? 'auto-fit' : 'auto-fill'
  const gridTemplateColumns = 'repeat(' + mode + ', minmax(min(100%, 13rem), 1fr))'

  return (
    <>
      <PageHeading
        title="Auto-fill / auto-fit"
        description="Сравни ширину двух карточек в обоих режимах на широком экране."
      />
      <div className="mb-5 rounded-2xl border border-stroke bg-panel p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <span id="card-count-label" className="text-sm font-bold text-ink">Карточки</span>
            <div role="group" aria-labelledby="card-count-label" className="flex gap-1 rounded-lg bg-canvas p-1">
              {cardCounts.map((option) => (
                <button
                  key={option}
                  type="button"
                  aria-pressed={count === option}
                  className={clsx(
                    'min-h-8 min-w-9 rounded-md px-2 text-sm font-extrabold',
                    count === option ? 'bg-accent text-white' : 'text-muted hover:bg-accent-tint hover:text-accent',
                  )}
                  onClick={() => setCount(option)}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
          <button
            type="button"
            className="min-h-10 rounded-lg border border-accent-soft px-3 py-2 text-sm font-bold text-accent hover:bg-accent-tint"
            onClick={() => setMode(nextMode)}
          >
            Включить {nextMode}
          </button>
        </div>
        <p role="status" className="mt-3 text-sm leading-relaxed text-muted">
          <code className="font-semibold text-accent">{mode}</code>
          {mode === 'auto-fill'
            ? ' оставляет место под пустые колонки.'
            : ' сворачивает пустые колонки и даёт карточкам больше места.'}
        </p>
      </div>
      <PhotoGallery items={photos.slice(0, count)} style={{ gridTemplateColumns }} />
    </>
  )
}
