import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { PageHeading } from '../components/PageHeading'
import { photos, type Photo } from '../photos'

const dailyVisits = [
  { day: 'Пн', count: 8 },
  { day: 'Вт', count: 12 },
  { day: 'Ср', count: 10 },
  { day: 'Чт', count: 15 },
  { day: 'Пт', count: 13 },
  { day: 'Сб', count: 18 },
  { day: 'Вс', count: 10 },
]
const totalVisits = dailyVisits.reduce((sum, { count }) => sum + count, 0)
const maximumVisits = Math.max(...dailyVisits.map(({ count }) => count))

const topicCounts = new Map<Photo['category'], number>()
for (const { category } of photos) {
  topicCounts.set(category, (topicCounts.get(category) ?? 0) + 1)
}

const metrics = [
  { label: 'Фотографии', value: photos.length },
  { label: 'Темы', value: topicCounts.size },
  { label: 'Просмотры каталога', value: 48 },
  { label: 'Открытия фото', value: 38 },
]

const block = 'min-w-0 rounded-2xl border border-stroke bg-panel p-4 sm:p-5'

export function DashboardPage() {
  return (
    <>
      <PageHeading title="Дашборд" description="Bento-раскладка со статистикой и темами фотогалереи. Данные о посещениях учебные." />
      <div role="group" aria-label="Дашборд галереи" className="grid auto-rows-[minmax(8rem,auto)] grid-cols-1 gap-4 md:grid-cols-4">
        <section className={clsx(block, 'flex flex-col md:col-span-2 md:row-span-2')} aria-labelledby="visits-title">
          <h2 id="visits-title" className="text-sm font-bold text-muted">Посещения за неделю</h2>
          <p className="mt-2 text-4xl font-extrabold tracking-tight">{totalVisits}</p>
          <ol aria-label="Посещения по дням недели" className="mt-auto grid grid-cols-7 items-end gap-1 pt-5 sm:gap-2">
            {dailyVisits.map(({ day, count }) => (
              <li key={day} className="flex min-w-0 flex-col items-center gap-1 text-xs font-bold text-muted">
                <span>{count}</span>
                <span
                  aria-hidden="true"
                  className={clsx('w-full max-w-9 rounded-t-md', count === maximumVisits ? 'bg-accent' : 'bg-accent-soft')}
                  style={{ height: (count / maximumVisits) * 80 }}
                />
                <span>{day}</span>
              </li>
            ))}
          </ol>
        </section>

        {metrics.map(({ label, value }) => (
          <article key={label} className={block}>
            <h2 className="text-sm leading-snug font-bold text-muted">{label}</h2>
            <p className="mt-3 text-3xl font-extrabold tracking-tight">{value}</p>
          </article>
        ))}

        <section aria-labelledby="topics-title" className={clsx(block, 'md:col-span-3')}>
          <h2 id="topics-title" className="text-base font-extrabold">Темы коллекции</h2>
          <ul className="mt-3 flex flex-wrap gap-2">
            {[...topicCounts].map(([topic, count]) => (
              <li key={topic} className="rounded-lg bg-accent-tint px-3 py-1.5 text-sm font-bold text-accent">
                {topic} · {count}
              </li>
            ))}
          </ul>
        </section>

        <article className="flex min-w-0 flex-col items-start justify-between gap-3 rounded-2xl border border-accent-soft bg-accent-tint p-4 sm:p-5">
          <h2 className="text-base font-extrabold">Каталог</h2>
          <Link className="rounded-sm text-sm font-bold text-accent underline-offset-4 hover:underline" to="/catalog">
            Открыть каталог
          </Link>
        </article>
      </div>
    </>
  )
}
