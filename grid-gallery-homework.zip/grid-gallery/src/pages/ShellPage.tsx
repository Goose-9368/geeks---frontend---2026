import { PageHeading } from '../components/PageHeading'

export function ShellPage() {
  return (
    <>
      <PageHeading
        title="Каркас страницы"
        description="Шапка, сайдбар, контент и подвал образуют общий каркас галереи."
      />
      <div className="rounded-2xl border border-stroke bg-panel p-4 sm:p-5">
        <div className="grid grid-cols-1 gap-2 text-sm font-bold md:grid-cols-[11rem_minmax(0,1fr)]">
          <div className="rounded-xl bg-accent-tint px-4 py-3 text-accent md:col-span-2">Шапка</div>
          <div className="hidden rounded-xl bg-canvas p-4 md:block">Сайдбар</div>
          <div className="min-h-24 rounded-xl border border-dashed border-accent-soft p-4">Контент</div>
          <div className="rounded-xl bg-accent-tint px-4 py-3 text-accent md:col-span-2">Подвал</div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Средняя строка с размером <code className="font-semibold text-accent">1fr</code> заполняет свободную высоту.
          На узком экране ссылки на раскладки доступны в шапке.
        </p>
      </div>
    </>
  )
}
