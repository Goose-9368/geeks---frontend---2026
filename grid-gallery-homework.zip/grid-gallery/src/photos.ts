import autumn from './assets/photos/autumn.jpg'
import aurora from './assets/photos/aurora.jpg'
import canyon from './assets/photos/canyon.jpg'
import coast from './assets/photos/coast.jpg'
import dunes from './assets/photos/dunes.jpg'
import falls from './assets/photos/falls.jpg'
import forest from './assets/photos/forest.jpg'
import hills from './assets/photos/hills.jpg'
import lake from './assets/photos/lake.jpg'
import lavender from './assets/photos/lavender.jpg'
import river from './assets/photos/river.jpg'
import summit from './assets/photos/summit.jpg'

type PhotoCategory = 'Вода' | 'Рельеф' | 'Лес' | 'Поля' | 'Небо'

export interface Photo {
  id: string
  title: string
  category: PhotoCategory
  description: string
  image: string
  alt: string
}

export const photos: readonly Photo[] = [
  {
    id: 'lake',
    title: 'Горное озеро',
    category: 'Вода',
    description: 'Бирюзовая вода у подножия Альп.',
    image: lake,
    alt: 'Бирюзовое озеро среди хвойных деревьев и гор',
  },
  {
    id: 'dunes',
    title: 'Песчаные дюны',
    category: 'Рельеф',
    description: 'Тонкие линии на песке в вечернем свете.',
    image: dunes,
    alt: 'Волны золотого песка на закате',
  },
  {
    id: 'forest',
    title: 'Лес в тумане',
    category: 'Лес',
    description: 'Туман скрывает дальний склон хвойного леса.',
    image: forest,
    alt: 'Хвойные деревья на покрытом туманом склоне',
  },
  {
    id: 'coast',
    title: 'Скалистый берег',
    category: 'Вода',
    description: 'Вид сверху на океан и линию прибоя.',
    image: coast,
    alt: 'Белые океанские волны у каменистого берега',
  },
  {
    id: 'falls',
    title: 'Водопад',
    category: 'Вода',
    description: 'Потоки воды спускаются по скале, покрытой мхом.',
    image: falls,
    alt: 'Водопад на зелёном скалистом склоне',
  },
  {
    id: 'canyon',
    title: 'Каньон Антилопы',
    category: 'Рельеф',
    description: 'Свет подчёркивает изгибы красного песчаника.',
    image: canyon,
    alt: 'Изогнутые слои песчаника внутри каньона',
  },
  {
    id: 'summit',
    title: 'Снежная вершина',
    category: 'Рельеф',
    description: 'Розовый закат над заснеженной горой.',
    image: summit,
    alt: 'Снежная гора в розовых лучах заката',
  },
  {
    id: 'river',
    title: 'Река в долине',
    category: 'Вода',
    description: 'Русло реки извивается между зелёными склонами.',
    image: river,
    alt: 'Река между зелёными горами, вид сверху',
  },
  {
    id: 'autumn',
    title: 'Осенняя тропа',
    category: 'Лес',
    description: 'Лесная дорожка среди деревьев с золотыми листьями.',
    image: autumn,
    alt: 'Тропинка через осенний лес',
  },
  {
    id: 'lavender',
    title: 'Поле лаванды',
    category: 'Поля',
    description: 'Фиолетовые ряды лаванды на закате.',
    image: lavender,
    alt: 'Ряды цветущей лаванды под вечерним небом',
  },
  {
    id: 'aurora',
    title: 'Северное сияние',
    category: 'Небо',
    description: 'Зелёное сияние над горными силуэтами.',
    image: aurora,
    alt: 'Зелёные полосы северного сияния над горами',
  },
  {
    id: 'hills',
    title: 'Холмы Тосканы',
    category: 'Поля',
    description: 'Поля и кипарисы в мягком свете рассвета.',
    image: hills,
    alt: 'Плавные линии тосканских холмов и ряды кипарисов',
  },
]
