import { benefits } from "../content";

export function Benefits() {
  return (
    <section id="benefits" aria-labelledby="benefits-title" className="scroll-mt-16 border-y border-line bg-linen">
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 sm:py-16 lg:px-12 lg:py-19">
        <h2 id="benefits-title" className="mb-7 font-display text-5xl leading-none font-semibold tracking-tight sm:mb-9 sm:text-6xl">
          Что входит в абонемент
        </h2>
        <ul className="-m-2 flex flex-wrap">
          {benefits.map(({ id, icon, title, description }) => (
            <li id={id} key={id} className="w-full scroll-mt-24 p-2 md:w-1/2 lg:w-1/3">
              <article className="h-full rounded-2xl border border-line bg-card p-5 sm:p-6">
                <span aria-hidden="true" className="mb-4 inline-flex size-11 items-center justify-center rounded-full bg-linen text-xl">
                  {icon}
                </span>
                <h3 className="text-base font-extrabold sm:text-lg">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{description}</p>
              </article>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
