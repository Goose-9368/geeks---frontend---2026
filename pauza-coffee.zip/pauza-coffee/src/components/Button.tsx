import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../lib/cn";

interface ButtonStyleProps {
  variant?: "primary" | "secondary";
  size?: "sm" | "md" | "lg";
  className?: string;
}

type LinkButtonProps = ButtonStyleProps & ComponentPropsWithoutRef<"a"> & { href: string };
type NativeButtonProps = ButtonStyleProps & ComponentPropsWithoutRef<"button"> & { href?: never };
export type ButtonProps = LinkButtonProps | NativeButtonProps;

const variants = {
  primary: "border-accent bg-accent text-white hover:border-accent-dark hover:bg-accent-dark",
  secondary: "border-line bg-transparent text-ink hover:border-accent hover:bg-linen",
};

const sizes = {
  sm: "min-h-10 px-4 py-2 text-sm",
  md: "min-h-11 px-5 py-2.5 text-sm",
  lg: "min-h-12 px-6 py-3 text-sm sm:text-base",
};

export function Button({ variant = "primary", size = "md", className, ...props }: ButtonProps) {
  const classes = cn(
    "inline-flex items-center justify-center rounded-full border text-center font-bold",
    "motion-safe:transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent",
    "enabled:cursor-pointer disabled:cursor-not-allowed disabled:opacity-50",
    variants[variant],
    sizes[size],
    className,
  );

  if (props.href !== undefined) {
    return <a {...props} className={classes} />;
  }

  const { href, type = "button", ...buttonProps } = props;
  return <button {...buttonProps} className={classes} type={type} />;
}
