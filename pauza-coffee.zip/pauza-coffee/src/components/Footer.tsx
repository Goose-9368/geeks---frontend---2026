import { plans } from "../content";

const linkGroups = [
  {
    title: "Кофейня",
    links: [
      { href: "#home", label: "О кофейне" },
      { href: "#benefits", label: "Преимущества" },
    ],
  },
  {
    title: "Абонементы",
    links: plans.map((plan) => ({ href: "#" + plan.id, label: plan.title })),
  },
  {
    title: "Наш кофе",
    links: [
      { href: "#beans", label: "Обжарка зерна" },
      { href: "#drinks", label: "Выбор напитков" },
      { href: "#milk", label: "Овсяное молоко" },
    ],
  },
  {
    title: "Правила",
    links: [
      { href: "#pickup", label: "Как забрать кофе" },
      { href: "#duration", label: "Срок действия" },
      { href: "#balance", label: "Как узнать остаток" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="bg-espresso text-paper">
      <div className="mx-auto max-w-7xl px-5 py-10 sm:px-8 sm:py-12 lg:px-12">
        <nav aria-label="Ссылки в подвале" className="-mx-3 flex flex-wrap gap-y-8">
          {linkGroups.map(({ title, links }) => (
            <div key={title} className="w-full px-3 md:w-1/2 lg:w-1/4">
              <h2 className="text-sm font-extrabold">{title}</h2>
              <ul className="mt-3 space-y-2.5">
                {links.map(({ href, label }) => (
                  <li key={href}>
                    <a
                      href={href}
                      className="rounded-sm text-sm text-oat underline-offset-4 hover:text-white hover:underline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-oat"
                    >
                      {label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
        <p className="mt-8 border-t border-oat/25 pt-6 text-xs text-oat">Пауза · Бишкек</p>
      </div>
    </footer>
  );
}
