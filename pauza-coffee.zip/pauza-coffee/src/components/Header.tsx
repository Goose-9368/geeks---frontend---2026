import { useRef, useState } from "react";
import { navigation } from "../content";
import { cn } from "../lib/cn";

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);

  return (
    <header
      className="sticky top-0 z-20 border-b border-line bg-paper"
      onKeyDown={(event) => {
        if (event.key === "Escape" && isOpen) {
          setIsOpen(false);
          menuButton.current?.focus();
        }
      }}
    >
      <div className="mx-auto flex min-h-17 max-w-7xl flex-wrap items-center justify-between px-5 py-3 sm:px-8 md:py-0 lg:px-12">
        <a
          href="#home"
          aria-label="Пауза, к началу"
          onClick={() => setIsOpen(false)}
          className="inline-flex items-center gap-3 rounded-md focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent"
        >
          <span aria-hidden="true" className="flex size-8 items-center justify-center gap-1 rounded-lg bg-accent">
            <span className="h-3.5 w-1 rounded-full bg-paper" />
            <span className="h-3.5 w-1 rounded-full bg-paper" />
          </span>
          <span className="font-display text-[2.2rem] leading-none font-semibold tracking-tight">пауза.</span>
        </a>

        <button
          ref={menuButton}
          type="button"
          aria-label={isOpen ? "Закрыть меню" : "Открыть меню"}
          aria-controls="site-navigation"
          aria-expanded={isOpen}
          onClick={() => setIsOpen((open) => !open)}
          className="flex size-11 cursor-pointer items-center justify-center rounded-full border border-line text-ink hover:bg-linen focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent md:hidden"
        >
          {isOpen ? (
            <span aria-hidden="true" className="text-2xl leading-none">×</span>
          ) : (
            <span aria-hidden="true" className="flex w-4 flex-col gap-1">
              <span className="h-0.5 rounded-full bg-current" />
              <span className="h-0.5 rounded-full bg-current" />
              <span className="h-0.5 rounded-full bg-current" />
            </span>
          )}
        </button>

        <nav
          id="site-navigation"
          aria-label="Основная навигация"
          className={cn("w-full border-t border-line py-3 md:block md:w-auto md:border-0 md:p-0", !isOpen && "hidden")}
        >
          <ul className="flex flex-col gap-1 md:flex-row md:items-center md:gap-8">
            {navigation.map(({ href, label }) => (
              <li key={href}>
                <a
                  href={href}
                  onClick={() => setIsOpen(false)}
                  className="block rounded-md px-2 py-2 text-sm font-bold text-muted hover:text-accent focus-visible:outline-2 focus-visible:outline-accent md:px-0"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
