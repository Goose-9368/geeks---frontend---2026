import coffeePhoto from "../assets/pauza-coffee.jpg";
import { Button } from "./Button";

export function Hero() {
  return (
    <section id="home" aria-labelledby="home-title" className="scroll-mt-20">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-9 px-5 py-11 sm:gap-11 sm:px-8 sm:py-14 lg:flex-row lg:gap-12 lg:px-12 lg:py-18 xl:gap-16">
        <div className="w-full max-w-xl text-center lg:max-w-none lg:flex-1 lg:text-left">
          <p className="mb-5 text-xs font-extrabold tracking-[0.16em] text-accent uppercase">
            Кофейня в Бишкеке
          </p>
          <h1 id="home-title" className="font-display text-[clamp(3.4rem,6.4vw,6.2rem)] leading-[0.92] font-semibold tracking-[-0.055em]">
            Кофе на
            <em className="block text-accent"> каждый день.</em>
          </h1>
          <p className="mx-auto mt-6 max-w-md text-base leading-relaxed text-muted sm:text-lg lg:mx-0">
            Выбери абонемент на 5, 10 или 20 чашек. Забирай любимый напиток в любой удобный день.
          </p>
          <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row lg:justify-start">
            <Button href="#plans" size="lg" className="w-full max-w-64 sm:w-auto">Выбрать абонемент</Button>
            <Button href="#benefits" variant="secondary" size="lg" className="w-full max-w-64 sm:w-auto">
              Что входит
            </Button>
          </div>
        </div>
        <img
          src={coffeePhoto}
          alt="Керамическая чашка кофе на деревянном столе в солнечном свете"
          fetchPriority="high"
          className="aspect-[6/5] w-full rounded-3xl bg-oat object-cover sm:aspect-[16/10] sm:max-w-2xl lg:aspect-[5/4] lg:w-[50%] lg:max-w-none lg:shrink-0 lg:rounded-4xl"
        />
      </div>
    </section>
  );
}
