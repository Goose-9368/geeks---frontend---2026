import { useState } from "react";
import { plans, type Plan } from "../content";
import { cn } from "../lib/cn";
import { Button } from "./Button";

const numberFormat = new Intl.NumberFormat("ru-RU");

export function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);

  return (
    <section id="plans" aria-labelledby="plans-title" className="scroll-mt-16">
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 sm:py-16 lg:px-12 lg:py-19">
        <h2 id="plans-title" className="font-display text-5xl leading-none font-semibold tracking-tight sm:text-6xl">
          Абонементы
        </h2>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted sm:text-base">
          Каждый абонемент действует 30 дней. Выбери, сколько чашек тебе нужно.
        </p>

        <ul className="mt-7 flex flex-col gap-4 md:mt-9 md:flex-row">
          {plans.map((plan) => {
            const isSelected = selectedPlan?.id === plan.id;

            return (
              <li id={plan.id} key={plan.id} className="min-w-0 scroll-mt-24 md:flex-1">
                <article
                  className={cn(
                    "flex h-full flex-col rounded-3xl border p-6 md:p-5 lg:p-7",
                    plan.featured ? "border-espresso bg-espresso text-paper" : "border-line bg-card",
                    isSelected && "ring-2 ring-accent ring-offset-3 ring-offset-paper",
                  )}
                >
                  <div className="mb-3 flex min-h-7 flex-wrap items-center justify-between gap-2">
                    <span className={cn("text-xs font-extrabold tracking-widest uppercase", plan.featured ? "text-oat" : "text-accent")}>
                      {plan.cups} чашек
                    </span>
                    {plan.featured && (
                      <span className="rounded-full bg-oat px-2.5 py-1 text-xs font-extrabold text-ink">
                        Популярный
                      </span>
                    )}
                  </div>
                  <h3 className="font-display text-4xl leading-none font-semibold">{plan.title}</h3>
                  <p className={cn("mt-2 min-h-12 text-sm leading-relaxed", plan.featured ? "text-oat" : "text-muted")}>
                    {plan.description}
                  </p>
                  <p className="mt-6 text-3xl font-extrabold tracking-tight">
                    {numberFormat.format(plan.price)} <span className="text-base tracking-normal">сом</span>
                  </p>
                  <p className={cn("mt-1 mb-6 text-sm", plan.featured ? "text-oat" : "text-muted")}>
                    {numberFormat.format(plan.price / plan.cups)} сом за чашку
                  </p>
                  <Button
                    variant={plan.featured ? "primary" : "secondary"}
                    aria-pressed={isSelected}
                    aria-label={(isSelected ? "Выбран тариф «" : "Выбрать тариф «") + plan.title + "»"}
                    onClick={() => setSelectedPlan(isSelected ? null : plan)}
                    className={cn(
                      "mt-auto w-full",
                      plan.featured && "border-paper bg-paper text-ink hover:border-oat hover:bg-oat focus-visible:outline-paper",
                    )}
                  >
                    {isSelected ? "Выбран" : "Выбрать"}
                  </Button>
                </article>
              </li>
            );
          })}
        </ul>

        <p role="status" className={cn("text-center text-sm font-bold text-accent", selectedPlan && "mt-5")}>
          {selectedPlan && ("Выбран абонемент «" + selectedPlan.title + "». " + selectedPlan.cups + " чашек за " + numberFormat.format(selectedPlan.price) + " сом.")}
        </p>
      </div>
    </section>
  );
}
