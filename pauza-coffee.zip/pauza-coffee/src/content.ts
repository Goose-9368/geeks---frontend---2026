export const navigation = [
  { href: "#home", label: "О кофейне" },
  { href: "#benefits", label: "Как это работает" },
  { href: "#plans", label: "Абонементы" },
];

interface Benefit {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export const benefits: Benefit[] = [
  {
    id: "beans",
    icon: "🫘",
    title: "Зерно средней обжарки",
    description: "Мягкий вкус с нотами шоколада и орехов в каждой чашке.",
  },
  {
    id: "drinks",
    icon: "☕",
    title: "Три напитка на выбор",
    description: "Американо, капучино и латте объёмом 250 мл входят в каждый абонемент.",
  },
  {
    id: "milk",
    icon: "🌾",
    title: "Овсяное молоко",
    description: "Для латте и капучино можно выбрать овсяное молоко.",
  },
  {
    id: "pickup",
    icon: "🥡",
    title: "Кофе с собой",
    description: "Назови свой абонемент у стойки, чтобы забрать напиток в дорогу.",
  },
  {
    id: "duration",
    icon: "🗓️",
    title: "30 дней на чашки",
    description: "Срок начинается при покупке. Чашки можно использовать в удобные дни.",
  },
  {
    id: "balance",
    icon: "🧾",
    title: "Остаток у бариста",
    description: "После заказа бариста подскажет, сколько чашек ещё можно забрать.",
  },
];

export interface Plan {
  id: string;
  title: string;
  cups: number;
  price: number;
  description: string;
  featured?: boolean;
}

export const plans: Plan[] = [
  {
    id: "morning",
    title: "Утро",
    cups: 5,
    price: 750,
    description: "Чтобы попробовать наши напитки и найти любимый.",
  },
  {
    id: "rhythm",
    title: "Ритм",
    cups: 10,
    price: 1350,
    description: "Для тех, кто заходит за кофе несколько раз в неделю.",
    featured: true,
  },
  {
    id: "daily",
    title: "Каждый день",
    cups: 20,
    price: 2400,
    description: "Почти на весь месяц, если кофе — часть твоего рабочего дня.",
  },
];
