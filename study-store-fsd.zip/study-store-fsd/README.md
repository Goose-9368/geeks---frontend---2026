# Study Store — мини-маркетплейс на FSD

Домашняя работа Geeks по Feature-Sliced Design. Проект Study Store из контрольной разложен по шести слоям FSD. Компоненты написаны на TypeScript, пропсы описаны интерфейсами и типами.

В приложении есть каталог из 8 товаров, адаптивная сетка, добавление в корзину, изменение количества, удаление товаров и подсчёт суммы в сомах. Корзина сохраняется в localStorage.

## Запуск

Нужен Node.js 22.12 или новее. Рекомендуется Node.js 24 LTS; версия для nvm указана в `.nvmrc`.

Открой папку `study-store-fsd` в WebStorm или VS Code. В терминале этой папки выполни две команды.

```bash
npm ci
npm run dev
```

Открой адрес, который покажет терминал, обычно http://localhost:5173.

Не открывай `index.html` двойным кликом: проект запускается через Vite.

## Storybook

В отдельном терминале:

```bash
npm run storybook
```

Открой http://localhost:6006 → Shared → Button. Обязательные истории: Primary и Disabled. Дополнительно есть Secondary. В Controls можно менять текст, вариант и disabled.

## Материалы контрольной

| Задание | Реализация |
| --- | --- |
| 1a. Role и User | `src/entities/user/model/types.ts` |
| 1b. Admin extends User | Там же; типизированные примеры — `src/entities/user/model/examples.ts` |
| 1c. Swagger → api.d.ts | `swagger.json`, `src/shared/api/api.d.ts`, команда `npm run generate:api` |
| 2. Tailwind-каталог | `src/widgets/product-catalog/ui/ProductCatalog.tsx`, `src/entities/product/ui/ProductCard.tsx` |
| 3a. FSD ui/model/api | `src/features/add-to-cart/` и публичный `index.ts` |
| 3b. Button stories | `src/shared/ui/button/Button.stories.tsx` |

Текстовый ответ для формы с кодом и пояснениями: [docs/assignment-answers.md](docs/assignment-answers.md).

## Адаптивная сетка

`grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4`

| Ширина окна | Колонки |
| --- | --- |
| Меньше 768px | 1 |
| От 768px до 1279px | 2 |
| От 1280px | 4 |

`gap-4` задаёт 16px между карточками. Родительский контейнер: `mx-auto w-full max-w-7xl px-4`.

## Структура FSD

| Слой | Содержимое |
| --- | --- |
| `app` | Точка входа, корневой `App`, подключение `CartProvider` и глобальные стили |
| `pages` | `catalog` собирает страницу из шапки, каталога и корзины |
| `widgets` | `store-header` показывает навигацию и счётчик. `product-catalog` отображает сетку товаров. `cart` отображает позиции и итоговую сумму |
| `features` | `add-to-cart` содержит кнопку, логику добавления и учебный запрос API |
| `entities` | `product` содержит тип, список и карточку товара. `cart` хранит состояние и типы корзины. `user` содержит типы из контрольной |
| `shared` | Общая кнопка, форматирование цены и сгенерированные типы API |

Слайсы экспортируют используемые компоненты и типы через `index.ts`. Импорты между слоями идут сверху вниз. Например, `ProductCatalog` использует `ProductCard` из `entities` и `AddToCartButton` из `features`. Интерфейс `ProductCatalogProps` описывает список товаров, а `StoreHeaderProps` описывает счётчик корзины.

## Swagger и учебный API

```bash
npx openapi-typescript ./swagger.json -o ./src/shared/api/api.d.ts
```

Или `npm run generate:api`. `swagger.json` содержит пример спецификации OpenAPI 3.0.3. Вручную написанные Role, User, Admin находятся отдельно от автоматически сгенерированных типов.

Готовый тип `components["schemas"]["CartItem"]` используется в `features/add-to-cart/api/addToCart.ts`.

Отдельный backend не входит в исходное задание. Поэтому `addToCart` возвращает типизированный демонстрационный ответ, а корзина работает локально. Реальных сетевых запросов, авторизации, оплаты и оформления заказа нет. Пример OpenAPI описывает контракт, но сам по себе не запускает сервер.

Все 8 SVG-изображений включены в `public/images`: внешние сервисы изображений не нужны.

## Команды

| Команда | Назначение |
| --- | --- |
| `npm ci` | Установить зависимости из package-lock.json |
| `npm run dev` | Запустить приложение |
| `npm run generate:api` | Перегенерировать api.d.ts |
| `npm run check` | Проверить TypeScript и актуальность сгенерированных типов |
| `npm run build` | Проверить TypeScript и собрать приложение в dist |
| `npm run preview` | Посмотреть сборку приложения |
| `npm run storybook` | Запустить Storybook |
| `npm run build-storybook` | Собрать Storybook в storybook-static |

## Загрузка на GitHub — через терминал

1. Распакуй ZIP и открой терминал в папке, где лежит `package.json`.
2. На https://github.com/new создай пустой репозиторий `study-store-fsd`.
3. Выполни команды:

```bash
git init
git add .
git commit -m "Refactor Study Store to FSD"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/study-store-fsd.git
git push -u origin main
```

Перед выполнением замени `YOUR_USERNAME` на свой логин GitHub. Если репозиторий называется иначе, используй его точный URL. GitHub может попросить войти в аккаунт.

`git add .` включает `.storybook`, `.github` и `.gitignore`. `node_modules`, `dist` и `storybook-static` исключены через `.gitignore`.

## Загрузка на GitHub — через браузер

1. Создай репозиторий на https://github.com/new.
2. Выбери ссылку «uploading an existing file» или Add file → Upload files.
3. Загружай содержимое распакованной папки, чтобы `package.json` оказался в корне репозитория, а не внутри дополнительной папки.
4. На Mac нажми Command + Shift + . в Finder, чтобы увидеть скрытые файлы. Обязательно добавь `.storybook`, `.github`, `.gitignore` и `.nvmrc`.
5. Нажми Commit changes. Не загружай ZIP вместо исходников и не добавляй node_modules.

В проект включён `.github/workflows/ci.yml`: после push GitHub Actions проверяет типы и собирает приложение и Storybook. Этот workflow выполняет проверки; публикация сайта не настроена.

## Что объяснить преподавателю

- `avatarUrl?: string` — необязательное поле; `Role` — объединение строковых литералов.
- `Admin extends User` наследует поля User и добавляет permissions.
- Префиксы md и xl включают правила начиная с заданной ширины.
- ui отвечает за отображение, model — за состояние и логику, api — за работу с API.
- Storybook показывает состояния одного компонента отдельно от страницы.
- disabled передаётся в настоящий HTML-атрибут кнопки, а не только меняет её внешний вид.

## Документация

- [Vite](https://vite.dev/guide/)
- [Tailwind + Vite](https://tailwindcss.com/docs/installation/using-vite)
- [OpenAPI TypeScript](https://openapi-ts.dev/cli)
- [Feature-Sliced Design](https://feature-sliced.design/docs/reference/layers)
- [Storybook + React + Vite](https://storybook.js.org/docs/get-started/frameworks/react-vite)

