import { CartProvider } from "@/entities/cart";
import { CatalogPage } from "@/pages/catalog";

export function App() {
  return (
    <CartProvider>
      <CatalogPage />
    </CartProvider>
  );
}
