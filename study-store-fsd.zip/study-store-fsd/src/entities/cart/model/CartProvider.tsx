import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type { CartItem, CartProduct } from "./types";

interface CartContextValue {
  items: CartItem[];
  count: number;
  total: number;
  message: string;
  addItem: (product: CartProduct) => void;
  changeQuantity: (id: number, difference: number) => void;
  removeItem: (id: number) => void;
  clearCart: () => void;
}

const STORAGE_KEY = "study-store-cart-v1";
const CartContext = createContext<CartContextValue | null>(null);

function isCartItem(value: unknown): value is CartItem {
  if (!value || typeof value !== "object") return false;
  const item = value as Record<string, unknown>;
  return (
    typeof item.id === "number" && Number.isSafeInteger(item.id) && item.id > 0 &&
    typeof item.name === "string" &&
    typeof item.image === "string" &&
    typeof item.price === "number" && Number.isFinite(item.price) && item.price >= 0 &&
    typeof item.quantity === "number" &&
    Number.isSafeInteger(item.quantity) && item.quantity > 0
  );
}

function readCart(): CartItem[] {
  try {
    const saved: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
    return Array.isArray(saved) ? saved.filter(isCartItem) : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(readCart);
  const [message, setMessage] = useState("");

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // The cart still works in memory when browser storage is unavailable.
    }
  }, [items]);

  function addItem(product: CartProduct) {
    setItems((current) => {
      const exists = current.some((item) => item.id === product.id);
      return exists
        ? current.map((item) =>
            item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item,
          )
        : [...current, { ...product, quantity: 1 }];
    });
    setMessage(product.name + " — добавлено в корзину");
  }

  function changeQuantity(id: number, difference: number) {
    setItems((current) =>
      current
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity + difference } : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }

  function removeItem(id: number) {
    setItems((current) => current.filter((item) => item.id !== id));
    setMessage("Товар удалён из корзины");
  }

  function clearCart() {
    setItems([]);
    setMessage("Корзина очищена");
  }

  return (
    <CartContext.Provider
      value={{
        items,
        count: items.reduce((sum, item) => sum + item.quantity, 0),
        total: items.reduce((sum, item) => sum + item.price * item.quantity, 0),
        message,
        addItem,
        changeQuantity,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const cart = useContext(CartContext);
  if (!cart) throw new Error("useCart must be used inside CartProvider");
  return cart;
}
