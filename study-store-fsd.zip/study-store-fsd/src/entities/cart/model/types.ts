// Cart keeps its own item snapshot and does not import another entity slice.
export interface CartProduct {
  id: number;
  name: string;
  price: number;
  image: string;
}

export interface CartItem extends CartProduct {
  quantity: number;
}
