import type { Product } from "./types";

const image = (name: string) => import.meta.env.BASE_URL + "images/" + name + ".svg";

export const products: Product[] = [
  {
    id: 1, name: "Наушники Focus", category: "Аудио",
    description: "Твой плейлист. Твоя концентрация.",
    price: 3490, image: image("headphones"), label: "Выбор студентов",
  },
  {
    id: 2, name: "Клавиатура Type", category: "Аксессуары",
    description: "Для кода, заметок и новых идей.",
    price: 4290, image: image("keyboard"),
  },
  {
    id: 3, name: "Мышь Click", category: "Аксессуары",
    description: "Компактная, удобная, беспроводная.",
    price: 1590, image: image("mouse"),
  },
  {
    id: 4, name: "Лампа Light", category: "Рабочее место",
    description: "Мягкий свет для больших планов.",
    price: 2790, image: image("lamp"), label: "Новинка",
  },
  {
    id: 5, name: "Колонка Sound", category: "Аудио",
    description: "Хорошее настроение в одном касании.",
    price: 2390, image: image("speaker"),
  },
  {
    id: 6, name: "Веб-камера Meet", category: "Аксессуары",
    description: "Будь на связи с командой.",
    price: 3190, image: image("camera"),
  },
  {
    id: 7, name: "Блокнот Ideas", category: "Рабочее место",
    description: "У каждой идеи есть первая страница.",
    price: 590, image: image("notebook"),
  },
  {
    id: 8, name: "Термокружка Pause", category: "Рабочее место",
    description: "Маленький перерыв перед новым рывком.",
    price: 1290, image: image("mug"),
  },
];
