import type { ReactNode } from "react";
import { formatPrice } from "@/shared/lib/formatPrice";
import type { Product } from "../model/types";

interface ProductCardProps {
  product: Product;
  action: ReactNode;
}

export function ProductCard({ product, action }: ProductCardProps) {
  return (
    <article className="flex h-full flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white">
      <div className="relative bg-stone-100">
        <img
          src={product.image}
          alt={product.name}
          width="480"
          height="360"
          className="aspect-[4/3] w-full object-cover"
        />
        {product.label && (
          <span className="absolute left-4 top-4 rounded-full bg-white px-3 py-1 text-xs font-semibold text-stone-700">
            {product.label}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="mb-2 text-xs text-stone-500">{product.category}</p>
        <h3 className="text-lg font-bold tracking-tight">{product.name}</h3>
        <p className="mt-2 text-sm leading-6 text-stone-600">{product.description}</p>
        <p className="mb-5 mt-5 text-xl font-bold">{formatPrice(product.price)}</p>
        <div className="mt-auto">{action}</div>
      </div>
    </article>
  );
}
