export type { Role, User, Admin } from "./model/types";
export { userExample, adminExample } from "./model/examples";
