import type { Admin, User } from "./types";

export const userExample: User = {
  id: 1,
  name: "Студент",
  email: "student@example.com",
  role: "user",
};

export const adminExample: Admin = {
  id: 2,
  name: "Администратор",
  email: "admin@example.com",
  role: "admin",
  permissions: ["products:create", "products:edit", "products:delete"],
};
