import type { components } from "@/shared/api";

type AddToCartResponse = components["schemas"]["CartItem"];

// Demo API: no backend was provided in the assignment.
// The response uses the generated OpenAPI type.
export async function addToCart(productId: number): Promise<AddToCartResponse> {
  if (!Number.isSafeInteger(productId) || productId <= 0) {
    throw new Error("Некорректный идентификатор товара");
  }

  return { productId, quantity: 1 };
}
