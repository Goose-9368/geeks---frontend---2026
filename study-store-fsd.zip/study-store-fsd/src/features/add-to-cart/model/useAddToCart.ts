import { useState } from "react";
import { useCart } from "@/entities/cart";
import type { Product } from "@/entities/product";
import { addToCart } from "../api/addToCart";

export function useAddToCart(product: Product) {
  const { addItem, items } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const quantity = items.find((item) => item.id === product.id)?.quantity ?? 0;

  async function add() {
    if (loading) return;
    setLoading(true);
    setError("");

    try {
      await addToCart(product.id);
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
      });
    } catch {
      setError("Не удалось добавить товар. Попробуй ещё раз.");
    } finally {
      setLoading(false);
    }
  }

  return { add, loading, error, quantity };
}
