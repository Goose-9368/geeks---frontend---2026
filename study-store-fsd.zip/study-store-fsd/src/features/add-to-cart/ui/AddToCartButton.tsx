import type { Product } from "@/entities/product";
import { Button } from "@/shared/ui/button";
import { useAddToCart } from "../model/useAddToCart";

export function AddToCartButton({ product }: { product: Product }) {
  const { add, loading, error, quantity } = useAddToCart(product);

  return (
    <div>
      <Button
        className="w-full"
        onClick={add}
        disabled={loading}
        aria-label={"В корзину: " + product.name}
      >
        <span aria-hidden="true">+</span>
        {loading ? "Добавляем…" : "В корзину"}
      </Button>
      <p className="mt-2 min-h-5 text-center text-xs text-stone-600">
        {quantity > 0 ? "В корзине: " + quantity : " "}
      </p>
      {error && <p role="alert" className="mt-2 text-sm text-red-700">{error}</p>}
    </div>
  );
}
