import { useCart } from "@/entities/cart";
import { products } from "@/entities/product";
import { CartPanel } from "@/widgets/cart";
import { ProductCatalog } from "@/widgets/product-catalog";
import { StoreHeader } from "@/widgets/store-header";

export function CatalogPage() {
  const { count, message } = useCart();

  return (
    <>
      <a href="#catalog" className="sr-only z-20 bg-white p-4 focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
        Перейти к товарам
      </a>
      <StoreHeader cartCount={count} />

      <main className="mx-auto w-full max-w-7xl px-4 pb-12">
        <section className="grid gap-8 border-b border-stone-200 py-12 md:grid-cols-2 md:items-end md:py-16">
          <div>
            <p className="mb-5 text-xs font-bold uppercase tracking-[0.18em] text-brand-700">Твоё место для новых идей</p>
            <h1 className="max-w-xl text-4xl font-bold leading-[1.08] tracking-tight md:text-5xl xl:text-6xl">
              Для учёбы.<br />Для твоих идей.
            </h1>
          </div>
          <div className="max-w-md md:ml-auto">
            <p className="text-base leading-7 text-stone-600">Нужные вещи для рабочего стола, любимого плейлиста и продуктивного дня.</p>
            <a href="#catalog" className="mt-6 inline-flex min-h-11 items-center gap-3 font-semibold text-brand-700">
              Найти своё <span aria-hidden="true">↘</span>
            </a>
          </div>
        </section>

        <ProductCatalog products={products} />
        <CartPanel />
        <p role="status" aria-live="polite" className="mt-4 min-h-6 text-sm text-stone-600">{message}</p>
      </main>

      <footer className="border-t border-stone-200">
        <div className="mx-auto flex max-w-7xl flex-wrap justify-between gap-3 px-4 py-6 text-xs text-stone-500">
          <p>STUDY STORE · Бишкек</p>
          <p>Учебный проект · Geeks · 6 месяц</p>
        </div>
      </footer>
    </>
  );
}
