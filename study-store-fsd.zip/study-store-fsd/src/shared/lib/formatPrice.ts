const formatter = new Intl.NumberFormat("ru-RU", {
  maximumFractionDigits: 0,
});

export function formatPrice(value: number) {
  return formatter.format(value) + " сом";
}
