import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "./Button";

const meta = {
  title: "Shared/Button",
  component: Button,
  tags: ["autodocs"],
  args: {
    children: "В корзину",
    variant: "primary",
    disabled: false,
  },
  argTypes: {
    variant: {
      control: "select",
      options: ["primary", "secondary"],
    },
    disabled: { control: "boolean" },
    children: { control: "text" },
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: { variant: "primary", disabled: false },
};

export const Disabled: Story = {
  args: { variant: "primary", disabled: true },
};

export const Secondary: Story = {
  args: { variant: "secondary", children: "Продолжить покупки" },
};
