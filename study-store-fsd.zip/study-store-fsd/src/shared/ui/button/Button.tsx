import type { ButtonHTMLAttributes } from "react";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
}

export function Button({
  children,
  variant = "primary",
  type = "button",
  className = "",
  ...props
}: ButtonProps) {
  const colors =
    variant === "primary"
      ? "border-transparent bg-brand-600 text-white enabled:hover:bg-brand-700"
      : "border-stone-300 bg-white text-stone-800 enabled:hover:bg-stone-100";

  return (
    <button
      {...props}
      type={type}
      className={[
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border",
        "px-4 py-2.5 text-sm font-semibold transition-colors",
        "focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand-600",
        "disabled:cursor-not-allowed disabled:opacity-50",
        colors,
        className,
      ].join(" ")}
    >
      {children}
    </button>
  );
}
