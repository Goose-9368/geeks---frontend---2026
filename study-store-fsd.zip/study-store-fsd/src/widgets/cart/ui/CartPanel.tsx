import { useCart } from "@/entities/cart";
import { Button } from "@/shared/ui/button";
import { formatPrice } from "@/shared/lib/formatPrice";

export function CartPanel() {
  const { items, total, changeQuantity, removeItem, clearCart } = useCart();

  return (
    <section id="cart" aria-labelledby="cart-title" className="scroll-mt-8 rounded-2xl border border-stone-200 bg-white p-5 md:p-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 id="cart-title" className="text-2xl font-bold tracking-tight">Твоя корзина</h2>
        {items.length > 0 && (
          <Button variant="secondary" onClick={clearCart}>Очистить корзину</Button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="py-10">
          <p className="text-lg font-semibold">Здесь пока пусто</p>
          <p className="mt-2 text-sm leading-6 text-stone-600">Добавь в корзину то, что поможет учиться с удовольствием.</p>
          <a href="#catalog" className="mt-5 inline-block text-sm font-semibold text-brand-700 underline underline-offset-4">
            Перейти к каталогу
          </a>
        </div>
      ) : (
        <>
          <ul className="mt-6 divide-y divide-stone-200">
            {items.map((item) => (
              <li key={item.id} className="flex flex-wrap items-center gap-4 py-5">
                <img src={item.image} alt="" width="72" height="60" className="h-16 w-20 rounded-lg object-cover" />
                <div className="min-w-36 flex-1">
                  <h3 className="font-semibold">{item.name}</h3>
                  <p className="mt-1 text-sm text-stone-600">{formatPrice(item.price)} / шт.</p>
                </div>
                <div className="flex items-center gap-3">
                  <Button variant="secondary" aria-label={"Уменьшить количество: " + item.name} onClick={() => changeQuantity(item.id, -1)}>−</Button>
                  <span aria-label={"Количество: " + item.name} className="min-w-5 text-center font-semibold">{item.quantity}</span>
                  <Button variant="secondary" aria-label={"Увеличить количество: " + item.name} onClick={() => changeQuantity(item.id, 1)}>+</Button>
                </div>
                <p className="min-w-28 font-semibold">{formatPrice(item.price * item.quantity)}</p>
                <Button variant="secondary" aria-label={"Удалить: " + item.name} onClick={() => removeItem(item.id)}>Удалить</Button>
              </li>
            ))}
          </ul>
          <div className="mt-5 flex items-center justify-between border-t border-stone-200 pt-6 text-xl font-bold">
            <span>Итого</span>
            <span data-testid="cart-total">{formatPrice(total)}</span>
          </div>
        </>
      )}
    </section>
  );
}
