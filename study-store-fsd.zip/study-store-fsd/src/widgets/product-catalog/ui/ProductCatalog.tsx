import { ProductCard, type Product } from "@/entities/product";
import { AddToCartButton } from "@/features/add-to-cart";

interface ProductCatalogProps {
  products: readonly Product[];
}

export function ProductCatalog({ products }: ProductCatalogProps) {
  return (
    <section id="catalog" aria-labelledby="catalog-title" className="scroll-mt-8 py-10 md:py-12">
      <div className="mb-7 flex items-end justify-between gap-4">
        <div>
          <h2 id="catalog-title" className="text-2xl font-bold tracking-tight md:text-3xl">
            Маленькие помощники
          </h2>
          <p className="mt-2 text-sm text-stone-600">Большие планы начинаются с удобного места.</p>
        </div>
        <span className="shrink-0 text-sm text-stone-500">{products.length} товаров</span>
      </div>

      <div data-testid="product-grid" className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            action={<AddToCartButton product={product} />}
          />
        ))}
      </div>
    </section>
  );
}
