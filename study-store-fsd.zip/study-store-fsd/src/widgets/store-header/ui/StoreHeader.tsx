interface StoreHeaderProps {
  cartCount: number;
}

export function StoreHeader({ cartCount }: StoreHeaderProps) {
  return (
    <header className="border-b border-stone-200">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-6">
        <a
          href="#"
          aria-label="Study Store — на главную"
          className="flex items-center gap-2 text-lg font-black tracking-tight"
        >
          <span aria-hidden="true" className="inline-block h-3 w-3 rounded-full bg-brand-600" />
          STUDY STORE
        </a>
        <nav aria-label="Основная навигация" className="flex items-center gap-5 text-sm font-semibold">
          <a href="#catalog" className="hidden text-stone-600 hover:text-stone-950 sm:inline">Каталог</a>
          <a href="#cart" className="flex min-h-11 items-center gap-2 rounded-lg border border-stone-300 bg-white px-4">
            Корзина
            <span
              data-testid="cart-count"
              aria-label={"Товаров в корзине: " + cartCount}
              className="min-w-6 rounded-full bg-stone-900 px-1.5 py-0.5 text-center text-xs text-white"
            >
              {cartCount}
            </span>
          </a>
        </nav>
      </div>
    </header>
  );
}
