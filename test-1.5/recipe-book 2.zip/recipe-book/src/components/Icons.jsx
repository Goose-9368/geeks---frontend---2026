export function Icon({ name, size = 20, ...props }) {
  const paths = {
    chef: (
      <>
        <path d="M6 13a4 4 0 1 1 0-8 6 6 0 0 1 12 0 4 4 0 1 1 0 8v8H6Z" />
        <path d="M6 17h12" />
      </>
    ),
    heart: (
      <path d="m12 20-8.1-7.5C-1 7.5 5.6 1 10.2 5.1L12 6.7l1.8-1.6C18.4 1 25 7.5 20.1 12.5Z" />
    ),
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="m16 16 5 5" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    arrow: <path d="M19 12H5m6-6-6 6 6 6" />,
    star: <path d="m12 3 2.8 5.7 6.3.9-4.6 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9Z" />,
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    flame: (
      <path d="M12 3c2 5 5 6 5 9 1-1 2-2 2-4 5 8 1 13-7 13S1 13 8 8c-1 5 1 6 2 6-1-4 4-6 2-11Z" />
    ),
    check: <path d="m5 12 4 4L19 6" />,
    leaf: (
      <>
        <path d="M4 20C0 8 9 2 21 3c1 12-5 21-17 17Z" />
        <path d="M4 20 15 9" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      {paths[name]}
    </svg>
  );
}
