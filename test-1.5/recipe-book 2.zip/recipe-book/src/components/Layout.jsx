import {
  Link,
  NavLink,
  Outlet,
  ScrollRestoration,
  useNavigation,
  useLocation,
} from 'react-router-dom';
import { useRecipes } from '../context/RecipeContext';
import { Icon } from './Icons';

export function InitialLoading() {
  return (
    <div className="initial-loading" role="status">
      <span className="spinner" />
      <p>Загружаем книгу рецептов…</p>
    </div>
  );
}

export function Layout() {
  const navigation = useNavigation();
  const location = useLocation();
  const { favorites, storageError } = useRecipes();
  const loading = navigation.state !== 'idle';
  return (
    <>
      <a
        className="skip-link"
        href={`${location.pathname}${location.search}#main`}
        onClick={(event) => {
          event.preventDefault();
          document.getElementById('main')?.focus();
        }}
      >
        Перейти к содержимому
      </a>
      <header className="site-header">
        <div className="container header-inner">
          <Link to="/" className="brand">
            <span className="brand-icon">
              <Icon name="chef" size={25} />
            </span>
            вкусно<span className="brand-dot">.</span>
          </Link>
          <nav aria-label="Основная навигация">
            <NavLink to="/" end>
              <Icon name="grid" size={18} />
              <span>Каталог</span>
            </NavLink>
            <NavLink to="/favorites">
              <Icon name="heart" size={18} />
              <span>Избранное</span>
              <span className="count">{favorites.length}</span>
            </NavLink>
            <NavLink to="/recent">
              <Icon name="clock" size={18} />
              <span>Просмотренные</span>
            </NavLink>
          </nav>
        </div>
      </header>
      {loading && (
        <div className="navigation-loader" role="status" aria-live="polite">
          <span className="spinner" />
          Загружаем…
        </div>
      )}
      <main id="main" className="container main-content" aria-busy={loading} tabIndex={-1}>
        {storageError && (
          <p className="storage-warning" role="alert">
            Браузер запрещает сохранение. Избранное и история доступны до закрытия страницы.
          </p>
        )}
        <Outlet />
      </main>
      <footer className="site-footer container">
        <span className="footer-brand">
          <Icon name="chef" size={18} />
          вкусно.
        </span>
        <p>Простые идеи для вкусных дней.</p>
        <a href="https://dummyjson.com/docs/recipes" target="_blank" rel="noreferrer">
          Данные: DummyJSON ↗
        </a>
      </footer>
      <ScrollRestoration />
    </>
  );
}
