import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useRecipes } from '../context/RecipeContext';
import { difficultyLabel } from '../lib/model';
import { Icon } from './Icons';

export function RecipeImage({ src, alt, ...props }) {
  const [failed, setFailed] = useState(false);
  return src && !failed ? (
    <img src={src} alt={alt} onError={() => setFailed(true)} {...props} />
  ) : (
    <div className="image-placeholder" role="img" aria-label={alt}>
      <Icon name="chef" size={56} />
      <span>Фото недоступно</span>
    </div>
  );
}

export function FavoriteButton({ recipe, full = false }) {
  const { favorites, toggle } = useRecipes();
  const active = favorites.some((item) => item.id === recipe.id);
  return (
    <button
      type="button"
      className={`${full ? 'button favorite-full' : 'favorite-button'} ${active ? 'is-saved' : ''}`}
      aria-pressed={active}
      aria-label={`${active ? 'Убрать из избранного' : 'В избранное'}: ${recipe.name}`}
      onClick={() => toggle(recipe)}
    >
      <Icon name="heart" />
      {full && (active ? 'В избранном' : 'Сохранить рецепт')}
    </button>
  );
}

export function RecipeCard({ recipe }) {
  const time = recipe.prepTimeMinutes + recipe.cookTimeMinutes;
  return (
    <article className="recipe-card">
      <div className="card-image">
        <Link
          to={`/recipes/${recipe.id}`}
          aria-label={`Открыть рецепт: ${recipe.name}`}
          tabIndex={-1}
        >
          <RecipeImage src={recipe.image} alt={recipe.name} loading="lazy" />
        </Link>
        <span className="cuisine-tag">{recipe.cuisine || 'Рецепт'}</span>
        <FavoriteButton recipe={recipe} />
      </div>
      <div className="card-body">
        <div className="card-heading">
          <span>{difficultyLabel(recipe.difficulty)}</span>
          <span className="rating">
            <Icon name="star" size={15} />
            {recipe.rating}
          </span>
        </div>
        <h2>
          <Link to={`/recipes/${recipe.id}`}>{recipe.name}</Link>
        </h2>
        <div className="card-meta">
          <span>
            <Icon name="clock" size={16} />
            {time} мин
          </span>
          <span>
            <Icon name="flame" size={16} />
            {recipe.caloriesPerServing} ккал
          </span>
        </div>
      </div>
    </article>
  );
}

export function RecipeGrid({ recipes }) {
  return (
    <div className="recipe-grid">
      {recipes.map((recipe) => (
        <RecipeCard key={recipe.id} recipe={recipe} />
      ))}
    </div>
  );
}
