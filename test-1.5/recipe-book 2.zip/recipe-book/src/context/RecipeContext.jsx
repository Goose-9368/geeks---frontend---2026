import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  FAVORITES_KEY,
  RECENT_KEY,
  RECENT_LIMIT,
  parseStored,
  toggleFavorite,
  addRecent,
} from '../lib/model';

const RecipeContext = createContext(null);

function read(key, limit) {
  try {
    return parseStored(localStorage.getItem(key), limit);
  } catch {
    return [];
  }
}

export function RecipeProvider({ children }) {
  const [favorites, setFavorites] = useState(() => read(FAVORITES_KEY));
  const [recent, setRecent] = useState(() => read(RECENT_KEY, RECENT_LIMIT));
  const [storageError, setStorageError] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
      localStorage.setItem(RECENT_KEY, JSON.stringify(recent));
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }, [favorites, recent]);

  useEffect(() => {
    const sync = (event) => {
      if (event.key === FAVORITES_KEY || event.key === null) setFavorites(read(FAVORITES_KEY));
      if (event.key === RECENT_KEY || event.key === null) setRecent(read(RECENT_KEY, RECENT_LIMIT));
    };
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);

  const toggle = useCallback(
    (recipe) => setFavorites((items) => toggleFavorite(items, recipe)),
    [],
  );
  const remember = useCallback((recipe) => setRecent((items) => addRecent(items, recipe)), []);
  const clearRecent = useCallback(() => setRecent([]), []);
  const value = useMemo(
    () => ({ favorites, recent, storageError, toggle, remember, clearRecent }),
    [favorites, recent, storageError, toggle, remember, clearRecent],
  );
  return <RecipeContext.Provider value={value}>{children}</RecipeContext.Provider>;
}

export function useRecipes() {
  const context = useContext(RecipeContext);
  if (!context) throw new Error('useRecipes должен использоваться внутри RecipeProvider.');
  return context;
}
