import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createHashRouter, RouterProvider } from 'react-router-dom';
import { RecipeProvider } from './context/RecipeContext';
import { Layout, InitialLoading } from './components/Layout';
import { Catalog } from './pages/Catalog';
import { RecipeDetail } from './pages/RecipeDetail';
import { Collection } from './pages/Collection';
import { ErrorPage } from './pages/ErrorPage';
import { catalogLoader, recipeLoader } from './lib/api';
import './styles.css';

// Hash-маршрутизация работает на GitHub Pages без настройки серверного fallback.
const router = createHashRouter([
  {
    path: '/',
    element: <Layout />,
    errorElement: <ErrorPage />,
    hydrateFallbackElement: <InitialLoading />,
    children: [
      { index: true, loader: catalogLoader, element: <Catalog />, errorElement: <ErrorPage /> },
      {
        path: 'recipes/:id',
        loader: recipeLoader,
        element: <RecipeDetail />,
        errorElement: <ErrorPage />,
      },
      { path: 'favorites', element: <Collection type="favorites" /> },
      { path: 'recent', element: <Collection type="recent" /> },
      {
        path: '*',
        loader: () => {
          throw new Response('Страница не найдена.', { status: 404 });
        },
        errorElement: <ErrorPage />,
      },
    ],
  },
]);

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RecipeProvider>
      <RouterProvider router={router} />
    </RecipeProvider>
  </StrictMode>,
);
