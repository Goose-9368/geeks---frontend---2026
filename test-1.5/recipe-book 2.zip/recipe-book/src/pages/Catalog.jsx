import { useEffect } from 'react';
import { Form, Link, useLoaderData, useSubmit } from 'react-router-dom';
import { RecipeGrid } from '../components/RecipeCard';
import { Icon } from '../components/Icons';
import { catalogUrl } from '../lib/model';

export function Catalog() {
  const { recipes, total, query, pages } = useLoaderData();
  const submit = useSubmit();
  useEffect(() => {
    document.title = 'Каталог — Вкусно';
  }, []);
  return (
    <>
      <section className="hero" aria-labelledby="catalog-title">
        <div className="hero-content">
          <span className="eyebrow">
            <Icon name="leaf" size={16} /> ГОТОВИТЬ — ЭТО ПРОСТО
          </span>
          <h1 id="catalog-title">
            Найдите свой
            <br />
            <em>новый любимый рецепт.</em>
          </h1>
          <p>
            Вдохновение для завтраков, семейных ужинов
            <br className="desktop-break" /> и маленьких кулинарных открытий.
          </p>
          <div className="hero-note">
            <span className="note-dot" />
            Выбирайте. Сохраняйте. Готовьте.
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-label">RECIPE BOOK / 01</div>
          <div className="plate">
            <div className="salad">
              <img src={`${import.meta.env.BASE_URL}salad.svg`} alt="" />
            </div>
          </div>
          <div className="floating-note">
            <Icon name="heart" size={17} />С любовью к еде
          </div>
        </div>
      </section>
      <section aria-label="Рецепты">
        <Form
          key={`${query.q}-${query.sortBy}-${query.order}`}
          method="get"
          action="/"
          className="catalog-tools"
        >
          <div className="search-field">
            <Icon name="search" />
            <label htmlFor="recipe-search" className="sr-only">
              Поиск рецептов
            </label>
            <input
              id="recipe-search"
              type="search"
              name="q"
              defaultValue={query.q}
              placeholder="Найти рецепт, например pasta"
            />
            <button className="search-button" type="submit">
              Найти
            </button>
          </div>
          <input type="hidden" name="page" value="1" />
          <div className="sort-field">
            <label htmlFor="sort-by">Сортировка</label>
            <select
              id="sort-by"
              name="sortBy"
              defaultValue={query.sortBy}
              onChange={(event) => submit(event.currentTarget.form)}
            >
              <option value="name">Название</option>
              <option value="rating">Рейтинг</option>
              <option value="caloriesPerServing">Калорийность</option>
            </select>
            <label htmlFor="sort-order" className="sr-only">
              Порядок сортировки
            </label>
            <select
              id="sort-order"
              name="order"
              defaultValue={query.order}
              onChange={(event) => submit(event.currentTarget.form)}
            >
              <option value="asc">По возрастанию</option>
              <option value="desc">По убыванию</option>
            </select>
          </div>
        </Form>
        <div className="section-heading">
          <h2>
            {query.q ? `Поиск: «${query.q}»` : 'Все рецепты'} <span>{total}</span>
          </h2>
          <p>{total ? `Страница ${query.page} из ${pages}` : 'Попробуйте другой запрос'}</p>
        </div>
        {!recipes.length ? (
          <div className="empty-state">
            <Icon name="search" size={42} />
            <h2>Ничего не нашлось</h2>
            <p>
              Названия в каталоге на английском.
              <br />
              Попробуйте pasta, chicken или salad.
            </p>
            <Link className="button" to="/">
              Все рецепты
            </Link>
          </div>
        ) : (
          <>
            <RecipeGrid recipes={recipes} />
            {pages > 1 && (
              <nav className="pagination" aria-label="Страницы каталога">
                {query.page > 1 ? (
                  <Link className="page-arrow" to={catalogUrl(query, query.page - 1)}>
                    ← Назад
                  </Link>
                ) : (
                  <span className="page-arrow disabled">← Назад</span>
                )}
                <div className="page-numbers">
                  {Array.from({ length: pages }, (_, index) => index + 1).map((page) => (
                    <Link
                      key={page}
                      to={catalogUrl(query, page)}
                      className={page === query.page ? 'current' : ''}
                      aria-current={page === query.page ? 'page' : undefined}
                      aria-label={`Страница ${page}`}
                    >
                      {page}
                    </Link>
                  ))}
                </div>
                {query.page < pages ? (
                  <Link className="page-arrow" to={catalogUrl(query, query.page + 1)}>
                    Далее →
                  </Link>
                ) : (
                  <span className="page-arrow disabled">Далее →</span>
                )}
              </nav>
            )}
          </>
        )}
      </section>
    </>
  );
}
