import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useRecipes } from '../context/RecipeContext';
import { RecipeGrid } from '../components/RecipeCard';
import { Icon } from '../components/Icons';

export function Collection({ type }) {
  const { favorites, recent, clearRecent } = useRecipes();
  const isRecent = type === 'recent';
  const recipes = isRecent ? recent : favorites;
  const title = isRecent ? 'Недавно просмотренные' : 'Мои любимые рецепты';
  useEffect(() => {
    document.title = `${title} — Вкусно`;
  }, [title]);
  return (
    <>
      <section className="collection-header">
        <span className="eyebrow">
          <Icon name={isRecent ? 'clock' : 'heart'} size={17} />
          ВАША КНИГА РЕЦЕПТОВ
        </span>
        <h1>{title}</h1>
        <p>
          {isRecent
            ? 'Последние 6 рецептов, которые вы открывали. Самые свежие — первыми.'
            : 'Все ваши кулинарные находки в одном месте.'}
        </p>
      </section>
      <div className="section-heading">
        <h2>
          {isRecent ? 'История просмотров' : 'Сохранённые рецепты'} <span>{recipes.length}</span>
        </h2>
        {isRecent && recipes.length > 0 && (
          <button type="button" className="text-button" onClick={clearRecent}>
            Очистить историю
          </button>
        )}
      </div>
      {recipes.length ? (
        <RecipeGrid recipes={recipes} />
      ) : (
        <div className="empty-state">
          <Icon name={isRecent ? 'clock' : 'heart'} size={44} />
          <h2>{isRecent ? 'Здесь появятся ваши просмотры' : 'Здесь будут ваши любимые блюда'}</h2>
          <p>
            {isRecent
              ? 'Откройте рецепт в каталоге — мы запомним его.'
              : 'Нажмите на сердечко у понравившегося рецепта.'}
          </p>
          <Link className="button" to="/">
            Открыть каталог <Icon name="arrow" className="arrow-right" size={17} />
          </Link>
        </div>
      )}
    </>
  );
}
