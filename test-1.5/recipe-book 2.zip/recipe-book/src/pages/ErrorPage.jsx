import { Link, isRouteErrorResponse, useRouteError, useRevalidator } from 'react-router-dom';
import { Icon } from '../components/Icons';

export function ErrorPage() {
  const error = useRouteError();
  const revalidator = useRevalidator();
  const notFound = isRouteErrorResponse(error) && error.status === 404;
  return (
    <section className="empty-state error-state" role="alert">
      <Icon name="chef" size={48} />
      <span className="eyebrow">
        {notFound ? '404 / СТРАНИЦА НЕ НАЙДЕНА' : 'НЕ УДАЛОСЬ ЗАГРУЗИТЬ'}
      </span>
      <h1>{notFound ? 'Кажется, этого рецепта нет' : 'Небольшая пауза на кухне'}</h1>
      <p>
        {notFound
          ? 'Проверьте адрес или выберите другой рецепт в каталоге.'
          : error instanceof Error
            ? error.message
            : 'Возникла ошибка. Попробуйте ещё раз.'}
      </p>
      <div className="error-actions">
        <Link className="button button-light" to="/">
          В каталог
        </Link>
        {!notFound && (
          <button
            className="button"
            type="button"
            disabled={revalidator.state !== 'idle'}
            onClick={() => revalidator.revalidate()}
          >
            {revalidator.state !== 'idle' ? 'Загружаем…' : 'Попробовать ещё раз'}
          </button>
        )}
      </div>
    </section>
  );
}
