import { useEffect } from 'react';
import { Link, useLoaderData } from 'react-router-dom';
import { RecipeImage, FavoriteButton } from '../components/RecipeCard';
import { Icon } from '../components/Icons';
import { useRecipes } from '../context/RecipeContext';
import { difficultyLabel } from '../lib/model';

export function RecipeDetail() {
  const recipe = useLoaderData();
  const { remember } = useRecipes();
  useEffect(() => {
    remember(recipe);
    document.title = `${recipe.name} — Вкусно`;
  }, [recipe, remember]);
  return (
    <>
      <Link to="/" className="back-link">
        <Icon name="arrow" size={18} />В каталог
      </Link>
      <section className="detail-hero">
        <div className="detail-image">
          <RecipeImage key={recipe.id} src={recipe.image} alt={recipe.name} fetchPriority="high" />
        </div>
        <div className="detail-summary">
          <span className="eyebrow">
            {recipe.cuisine} / {difficultyLabel(recipe.difficulty)}
          </span>
          <h1>{recipe.name}</h1>
          <div className="detail-rating">
            <Icon name="star" size={20} />
            <strong>{recipe.rating}</strong>
            <span>рейтинг рецепта</span>
          </div>
          <p className="detail-intro">
            Всё, что нужно для приготовления: ингредиенты, время и пошаговая инструкция.
          </p>
          <div className="detail-stats">
            <div>
              <Icon name="clock" />
              <strong>{recipe.prepTimeMinutes} мин</strong>
              <span>Подготовка</span>
            </div>
            <div>
              <Icon name="chef" />
              <strong>{recipe.cookTimeMinutes} мин</strong>
              <span>Приготовление</span>
            </div>
            <div>
              <Icon name="flame" />
              <strong>{recipe.caloriesPerServing} ккал</strong>
              <span>На порцию</span>
            </div>
          </div>
          <FavoriteButton recipe={recipe} full />
        </div>
      </section>
      <div className="recipe-content">
        <section className="ingredients">
          <span className="eyebrow">ЧТО ПОНАДОБИТСЯ</span>
          <h2>
            Ингредиенты <span>{recipe.ingredients.length}</span>
          </h2>
          <p>Отмечайте то, что уже подготовили.</p>
          <ul>
            {recipe.ingredients.map((ingredient, index) => (
              <li key={`${recipe.id}-${index}`}>
                <label>
                  <input type="checkbox" />
                  <span>{ingredient}</span>
                </label>
              </li>
            ))}
          </ul>
        </section>
        <section className="instructions">
          <span className="eyebrow">ШАГ ЗА ШАГОМ</span>
          <h2>Как приготовить</h2>
          <ol>
            {recipe.instructions.map((instruction, index) => (
              <li key={index}>
                <span className="step-number">{String(index + 1).padStart(2, '0')}</span>
                <p>{instruction}</p>
              </li>
            ))}
          </ol>
          <div className="bon-appetit">
            <Icon name="leaf" />
            Приятного аппетита!
          </div>
        </section>
      </div>
    </>
  );
}
