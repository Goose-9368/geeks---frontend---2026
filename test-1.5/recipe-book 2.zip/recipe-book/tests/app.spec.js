import { test, expect } from '@playwright/test';

const recipes = Array.from({ length: 23 }, (_, index) => ({
  id: index + 1,
  name: `${index % 2 ? 'Pasta' : 'Salad'} Recipe ${String(index + 1).padStart(2, '0')}`,
  image: '',
  cuisine: 'Italian',
  difficulty: 'Easy',
  rating: 4 + index / 100,
  prepTimeMinutes: 10,
  cookTimeMinutes: 20,
  caloriesPerServing: 200 + index,
  ingredients: ['Tomatoes', 'Olive oil'],
  instructions: ['Prepare ingredients.', 'Cook and serve.'],
}));

async function mockApi(page, { delay = 0, error = false } = {}) {
  await page.route('https://dummyjson.com/**', async (route) => {
    if (delay) await new Promise((resolve) => setTimeout(resolve, delay));
    if (error) return route.fulfill({ status: 500, json: { message: 'Unavailable' } });
    const url = new URL(route.request().url());
    if (/^\/recipes\/\d+$/.test(url.pathname)) {
      const recipe = recipes.find((item) => item.id === Number(url.pathname.split('/').pop()));
      return route.fulfill({
        status: recipe ? 200 : 404,
        json: recipe || { message: 'Not found' },
      });
    }
    const q = (url.searchParams.get('q') || '').toLowerCase();
    const items = recipes.filter((item) => item.name.toLowerCase().includes(q));
    const sortBy = url.searchParams.get('sortBy') || 'name';
    const direction = url.searchParams.get('order') === 'desc' ? -1 : 1;
    items.sort(
      (a, b) =>
        direction *
        (typeof a[sortBy] === 'string'
          ? a[sortBy].localeCompare(b[sortBy])
          : a[sortBy] - b[sortBy]),
    );
    const skip = Number(url.searchParams.get('skip') || 0),
      limit = Number(url.searchParams.get('limit') || 9);
    await route.fulfill({
      json: { recipes: items.slice(skip, skip + limit), total: items.length, skip, limit },
    });
  });
}

test('поиск, серверная сортировка, пагинация и загрузчик перехода', async ({ page }) => {
  await mockApi(page, { delay: 200 });
  await page.goto('/');
  await expect(page.locator('.recipe-card')).toHaveCount(9);
  await page.getByLabel('Поиск рецептов', { exact: true }).fill('Pasta');
  await page.getByRole('button', { name: 'Найти', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Загружаем');
  await expect(page.getByRole('heading', { name: 'Поиск: «Pasta» 11' })).toBeVisible();
  await page.getByLabel('Сортировка', { exact: true }).selectOption('rating');
  await expect(page).toHaveURL(/sortBy=rating/);
  await page.getByLabel('Порядок сортировки').selectOption('desc');
  await expect(page).toHaveURL(/order=desc/);
  await expect(page.locator('.recipe-card h2').first()).toHaveText('Pasta Recipe 22');
  await page.getByRole('link', { name: 'Далее →' }).click();
  await expect(page).toHaveURL(/page=2/);
  await expect(page.locator('.recipe-card')).toHaveCount(2);
  await expect(page.locator('.recipe-card h2').first()).toHaveText('Pasta Recipe 04');
  await page.reload();
  await expect(page.getByLabel('Поиск рецептов', { exact: true })).toHaveValue('Pasta');
  await expect(page.locator('.recipe-card')).toHaveCount(2);
  await page.goBack();
  await expect(page).toHaveURL(/page=1/);
});

test('избранное и история сохраняются, рецепт открывается напрямую', async ({ page }) => {
  await mockApi(page, { delay: 100 });
  await page.goto('/');
  await page.getByRole('button', { name: 'В избранное: Pasta Recipe 02', exact: true }).click();
  await page.getByRole('link', { name: /Избранное/ }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await page.getByRole('link', { name: 'Pasta Recipe 02', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Загружаем');
  await expect(page.getByRole('heading', { name: 'Pasta Recipe 02', exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Ингредиенты 2' })).toBeVisible();
  await page.getByRole('checkbox', { name: 'Tomatoes' }).check();
  await expect(page.getByRole('checkbox', { name: 'Tomatoes' })).toBeChecked();
  await page.reload();
  await expect(
    page.getByRole('button', { name: 'Убрать из избранного: Pasta Recipe 02' }),
  ).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('link', { name: 'Просмотренные' }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await page.getByRole('button', { name: 'Очистить историю' }).click();
  await expect(page.getByRole('heading', { name: 'Здесь появятся ваши просмотры' })).toBeVisible();
  await page.getByRole('link', { name: /Избранное/ }).click();
  await page.getByRole('button', { name: 'Убрать из избранного: Pasta Recipe 02' }).click();
  await expect(page.getByRole('heading', { name: 'Здесь будут ваши любимые блюда' })).toBeVisible();
});

test('пустой поиск, неверная страница и 404', async ({ page }) => {
  await mockApi(page);
  await page.goto('/#/?q=absent');
  await expect(page.getByRole('heading', { name: 'Ничего не нашлось' })).toBeVisible();
  await page.goto('/#/?page=999');
  await expect(page).toHaveURL(/page=3/);
  await expect(page.locator('.recipe-card')).toHaveCount(5);
  await page.goto('/#/recipes/9999');
  await expect(page.getByRole('heading', { name: 'Кажется, этого рецепта нет' })).toBeVisible();
  await page.goto('/#/wrong-path');
  await expect(page.getByRole('heading', { name: 'Кажется, этого рецепта нет' })).toBeVisible();
});

test('ошибка API и повторная загрузка', async ({ page }) => {
  await mockApi(page, { error: true });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Небольшая пауза на кухне' })).toBeVisible();
  await page.unroute('https://dummyjson.com/**');
  await mockApi(page);
  await page.getByRole('button', { name: 'Попробовать ещё раз' }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(9);
});

test('мобильная вёрстка, повреждённое хранилище и отсутствие ошибок JS', async ({ page }) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await mockApi(page);
  await page.addInitScript(() => {
    localStorage.setItem('recipe-book:favorites:v1', '{broken');
    localStorage.setItem('recipe-book:recent:v1', '[null,{"id":1,"name":{}}]');
  });
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto('/');
  await expect(page.locator('.recipe-card')).toHaveCount(9);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
  await page.getByRole('link', { name: 'Pasta Recipe 02', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Как приготовить' })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
  expect(errors).toEqual([]);
});

test('запрет localStorage не мешает работе избранного', async ({ page }) => {
  await mockApi(page);
  await page.addInitScript(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('Blocked', 'SecurityError');
    };
  });
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText('Браузер запрещает сохранение');
  await page.getByRole('button', { name: 'В избранное: Pasta Recipe 02', exact: true }).click();
  await page.getByRole('link', { name: /Избранное/ }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(1);
});

test('история ограничена шестью рецептами и повторный просмотр не дублируется', async ({
  page,
}) => {
  await mockApi(page);
  await page.goto('/#/recipes/1');
  for (let id = 2; id <= 8; id++) {
    await page.evaluate((nextId) => {
      window.location.hash = `/recipes/${nextId}`;
    }, id);
    await expect(page.locator('.detail-summary h1')).toHaveText(recipes[id - 1].name);
  }
  await page.getByRole('link', { name: 'Просмотренные' }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(6);
  await expect(page.locator('.recipe-card h2').first()).toHaveText(recipes[7].name);
  await page.getByRole('link', { name: recipes[4].name, exact: true }).click();
  await expect(page.locator('.detail-summary h1')).toHaveText(recipes[4].name);
  await page.getByRole('link', { name: 'Просмотренные' }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(6);
  await expect(page.locator('.recipe-card h2').first()).toHaveText(recipes[4].name);
});

test('избранное синхронизируется между вкладками', async ({ page, context }) => {
  const second = await context.newPage();
  await mockApi(page);
  await mockApi(second);
  await page.goto('/');
  await second.goto('/#/favorites');
  await expect(second.locator('.recipe-card')).toHaveCount(0);
  await page.getByRole('button', { name: 'В избранное: Pasta Recipe 02', exact: true }).click();
  await expect(second.locator('.recipe-card')).toHaveCount(1);
  await second
    .getByRole('button', { name: 'Убрать из избранного: Pasta Recipe 02', exact: true })
    .click();
  await expect(
    page.getByRole('button', { name: 'В избранное: Pasta Recipe 02', exact: true }),
  ).toHaveAttribute('aria-pressed', 'false');
});
