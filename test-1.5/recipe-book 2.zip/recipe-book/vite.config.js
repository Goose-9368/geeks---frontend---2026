import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Относительные пути позволяют разместить сборку в подпапке GitHub Pages.
  base: './',
  test: { include: ['src/**/*.test.js'], environment: 'node' },
});
